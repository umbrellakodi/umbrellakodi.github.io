"""Exercise Custom indicators without requiring Kodi or a live account."""
import ast
from pathlib import Path
from types import SimpleNamespace
import unittest

ROOT = Path(__file__).resolve().parents[1]


def load_function(filename, name, namespace):
    tree = ast.parse((ROOT / filename).read_text(encoding='utf-8-sig'))
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    exec(compile(ast.Module(body=[node], type_ignores=[]), filename, 'exec'), namespace)
    return namespace[name]


class CustomIndicatorTests(unittest.TestCase):
    def test_partial_watched_list_does_not_complete_season(self):
        function = load_function('resources/lib/modules/customtrakt.py', '_seasons_from_progress',
                                 dict(getSetting=lambda key: 'false'))
        watched, counts = function({'seasons': [{'number': 1, 'aired': 12, 'completed': 12,
                                                'episodes': [{'number': 1, 'completed': True}]}]})
        self.assertEqual(watched, [])
        self.assertEqual(counts[1]['unwatched'], 11)

    def test_explicit_unwatched_flags_override_completed_aggregate(self):
        function = load_function('resources/lib/modules/customtrakt.py', '_seasons_from_progress',
                                 dict(getSetting=lambda key: 'false'))
        unwatched = {2, 4, 5, 6, 7, 9, 10}
        watched, counts = function({'seasons': [{'number': 1, 'aired': 12, 'completed': 12,
                                                'episodes': [{'number': n, 'completed': n not in unwatched}
                                                             for n in range(1, 13)]}]})
        self.assertEqual(watched, [])
        self.assertEqual(counts[1]['unwatched'], 7)

    def test_missing_progress_episode_does_not_use_stale_watched_history(self):
        progress = {'seasons': [{'number': 2, 'aired': 13, 'completed': 1,
                                'episodes': [{'number': 1, 'completed': True}]}]}
        local = [({'imdb': 'tt0353049'}, 1, {2: [(12, 12)]})]
        self.assertEqual(self.overlay(progress, local), '4')

    def test_hidden_specials_do_not_add_thirteen_remaining_episodes(self):
        progress = {'seasons': [
            {'number': 0, 'aired': 13, 'completed': 0,
             'episodes': [{'number': n, 'completed': False} for n in range(1, 14)]},
            {'number': 1, 'aired': 12, 'completed': 12,
             'episodes': [{'number': n, 'completed': True} for n in range(1, 13)]},
            {'number': 2, 'aired': 13, 'completed': 13,
             'episodes': [{'number': n, 'completed': True} for n in range(1, 14)]}]}
        namespace = dict(getSetting=lambda key: 'false')
        function = load_function('resources/lib/modules/customtrakt.py', '_seasons_from_progress', namespace)
        watched, counts = function(progress)
        self.assertEqual(watched, ['1', '2'])
        self.assertEqual(sum(s['unwatched'] for s in counts.values()), 0)
        namespace['getSetting'] = lambda key: 'true'
        watched, counts = function(progress)
        self.assertEqual(sum(s['unwatched'] for s in counts.values()), 13)

    def overlay(self, progress, indicators):
        namespace = dict(customIndicators=True,
                         customtrakt=SimpleNamespace(getShowProgress=lambda imdb: progress))
        for name in ('trakt', 'simkl', 'mdblist', 'floppy', 'scrob', 'punchplay'):
            namespace[name + 'Indicators'] = False
        function = load_function('resources/lib/modules/playcount.py', 'getEpisodeOverlay', namespace)
        return function(indicators, 'tt0353049', '71862', '2', '12')

    def test_server_watched_overrides_missing_local_history(self):
        progress = {'seasons': [{'number': 2, 'episodes': [{'number': 12, 'completed': True}]}]}
        self.assertEqual(self.overlay(progress, []), '5')

    def test_server_unwatched_overrides_stale_local_history(self):
        progress = {'seasons': [{'number': 2, 'episodes': [{'number': 12, 'completed': False}]}]}
        local = [({'imdb': 'tt0353049'}, 1, {2: [(12, 12)]})]
        self.assertEqual(self.overlay(progress, local), '4')

    def test_local_fallback_when_progress_unavailable(self):
        local = [({'imdb': 'tt0353049'}, 1, {2: [(12, 12)]})]
        self.assertEqual(self.overlay(None, local), '5')

    def test_forced_history_reads_from_beginning_and_failure_keeps_cursor(self):
        from datetime import datetime
        requests, updates = [], []
        namespace = dict(datetime=datetime,
                         customtraktsync=SimpleNamespace(last_sync=lambda key: 1700000000,
                                                       update_last_watched_at=lambda key: updates.append(key)),
                         getActivity=lambda activities: 1700000100,
                         getCustomAsJson=lambda url: requests.append(url),
                         log_utils=SimpleNamespace(error=lambda: self.fail('Unexpected exception')))
        function = load_function('resources/lib/modules/customtrakt.py', 'sync_watchedProgress', namespace)
        function(forced=True)
        self.assertIn('since=1970-01-01T00:00:00Z', requests[0])
        self.assertEqual(updates, [])


if __name__ == '__main__':
    unittest.main()

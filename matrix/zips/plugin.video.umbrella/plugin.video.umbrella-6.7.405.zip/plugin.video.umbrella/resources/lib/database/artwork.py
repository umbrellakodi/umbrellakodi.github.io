#Added 2/11/25 by Umbrella_Dev for custom artwork
from resources.lib.modules import control
from resources.lib.modules.control import existsPath, dataPath, makeFile, artworkFile
from resources.lib.modules import log_utils
from sqlite3 import dbapi2 as db
from json import loads as jsloads, dumps as jsdumps

def fetch_movie(imdb, tmdb):
	list = ''
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name=?;''', ('movies',)).fetchone()
		if not ck_table:
			dbcur.execute('''CREATE TABLE IF NOT EXISTS %s (imdb TEXT, tmdb TEXT, poster TEXT, fanart TEXT, landscape TEXT, banner TEXT, clearart TEXT, clearlogo TEXT, discart TEXT, keyart TEXT, UNIQUE(imdb));''' % 'movies')
			dbcur.connection.commit()
			return list
		try:
			match = dbcur.execute('''SELECT * FROM movies WHERE imdb=?''' , (imdb,)).fetchall()
			list = [{'imdb': i[0], 'tmdb': i[1], 'poster': i[2], 'fanart': i[3], 'landscape': i[4], 'banner': i[5], 'clearart': i[6], 'clearlogo': i[7], 'discart': i[8], 'keyart': i[9]} for i in match]
		except: pass
	except:
		
		log_utils.error()
	finally:
		dbcur.close() ; dbcon.close()
	return list

def fetch_show(imdb=None, tmdb=None, tvdb=None):
	list = ''
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name=?;''', ('shows',)).fetchone()
		if not ck_table:
			dbcur.execute('''CREATE TABLE IF NOT EXISTS %s (imdb TEXT, tmdb TEXT, tvdb TEXT, poster TEXT, fanart TEXT, landscape TEXT, banner TEXT, clearart TEXT, clearlogo TEXT, season TEXT, episode TEXT, UNIQUE(imdb));''' % 'shows')
			dbcur.connection.commit()
			return list
		try:
			match = dbcur.execute('''SELECT * FROM shows WHERE imdb=? or tvdb=?''' , (imdb, tvdb,)).fetchall()
			list = [{'imdb': i[0], 'tmdb': i[1], 'tvdb': i[2], 'poster': i[3], 'fanart': i[4], 'landscape': i[5], 'banner': i[6], 'clearart': i[7], 'clearlogo': i[8], 'season': i[8], 'episode': i[9]} for i in match]
		except: pass
	except:
		
		log_utils.error()
	finally:
		dbcur.close() ; dbcon.close()
	return list

def manager(mediatype=None, imdb=None, tmdb=None, tvdb=None, season=None, episode=None):
	lists = []
	try:
		if season: season = int(season)
		if episode: episode = int(episode)
		#media_type = 'Show' if tvdb else 'Movie'
		mediatype = mediatype
		if mediatype == 'movie':
			items = [('poster', 'poster')]
			items += [('fanart', 'fanart')]
			items += [('landscape', 'landscape')]
			items += [('banner', 'banner')]
			items += [('clearart', 'clearart')]
			items += [('clearlogo', 'clearlogo')]
			items += [('discart', 'discart')]
			items += [('keyart', 'keyart')]
			items += [('reset all', 'reset all')]
		else:
			items = [('poster', 'poster')]
			items += [('fanart', 'fanart')]
			items += [('landscape', 'landscape')]
			items += [('banner', 'banner')]
			items += [('clearart', 'clearart')]
			items += [('clearlogo', 'clearlogo')]
			items += [('reset all', 'reset all')]

		control.hide()
		select = control.selectDialog([i[0] for i in items], heading=control.addonInfo('name') + ' - ' + 'Customize Artwork')
		refresh = True
		if select == -1: return
		if select >= 0:
			if items[select][1] == 'reset all':
				log_utils.log('Clear all custom art')
				delete_artwork(media_type=mediatype,imdb=imdb, tmdb=tmdb)
			if items[select][1] == 'poster':
				heading = str(items[select][1] ) + ' artwork for: %s' % control.infoLabel('Container.ListItem.Title')
				log_utils.log('Umbrella Customize Art "%s" Selected. Current %s is: %s' % (items[select][1], items[select][1], control.infoLabel('Container.ListItem.Art(poster)')), 1)
				show_artwork_window(imdb=imdb, tmdb=tmdb, tvdb=tvdb, mediatype=mediatype, heading=heading, artworktype=str(items[select][1]), title=control.infoLabel('Container.ListItem.Title'))
			if items[select][1] == 'fanart':
				heading = str(items[select][1] ) + ' artwork for: %s' % control.infoLabel('Container.ListItem.Title')
				log_utils.log('Umbrella Customize Art "%s" Selected. Current %s is: %s' % (items[select][1], items[select][1], control.infoLabel('Container.ListItem.Art(fanart)')), 1)
				show_artwork_window(imdb=imdb, tmdb=tmdb, tvdb=tvdb, mediatype=mediatype, heading=heading, artworktype=str(items[select][1]), title=control.infoLabel('Container.ListItem.Title'))
			if items[select][1] == 'landscape':
				heading = str(items[select][1] ) + ' artwork for: %s' % control.infoLabel('Container.ListItem.Title')
				log_utils.log('Umbrella Customize Art "%s" Selected. Current %s is: %s' % (items[select][1], items[select][1], control.infoLabel('Container.ListItem.Art(landscape)')), 1)
				show_artwork_window(imdb=imdb, tmdb=tmdb, tvdb=tvdb, mediatype=mediatype, heading=heading, artworktype=str(items[select][1]), title=control.infoLabel('Container.ListItem.Title'))
			if items[select][1] == 'banner':
				heading = str(items[select][1] ) + ' artwork for: %s' % control.infoLabel('Container.ListItem.Title')
				log_utils.log('Umbrella Customize Art "%s" Selected. Current %s is: %s' % (items[select][1], items[select][1], control.infoLabel('Container.ListItem.Art(banner)')), 1)
				show_artwork_window(imdb=imdb, tmdb=tmdb, tvdb=tvdb, mediatype=mediatype, heading=heading, artworktype=str(items[select][1]), title=control.infoLabel('Container.ListItem.Title'))
			if items[select][1] == 'clearart':
				heading = str(items[select][1] ) + ' artwork for: %s' % control.infoLabel('Container.ListItem.Title')
				log_utils.log('Umbrella Customize Art "%s" Selected. Current %s is: %s' % (items[select][1], items[select][1], control.infoLabel('Container.ListItem.Art(clearart)')), 1)
				show_artwork_window(imdb=imdb, tmdb=tmdb, tvdb=tvdb, mediatype=mediatype, heading=heading, artworktype=str(items[select][1]), title=control.infoLabel('Container.ListItem.Title'))
			if items[select][1] == 'clearlogo':
				heading = str(items[select][1] ) + ' artwork for: %s' % control.infoLabel('Container.ListItem.Title')
				log_utils.log('Umbrella Customize Art "%s" Selected. Current %s is: %s' % (items[select][1], items[select][1], control.infoLabel('Container.ListItem.Art(clearlogo)')), 1)
				show_artwork_window(imdb=imdb, tmdb=tmdb, tvdb=tvdb, mediatype=mediatype, heading=heading, artworktype=str(items[select][1]), title=control.infoLabel('Container.ListItem.Title'))
			if items[select][1] == 'discart':
				heading = str(items[select][1] ) + ' artwork for: %s' % control.infoLabel('Container.ListItem.Title')
				log_utils.log('Umbrella Customize Art "%s" Selected. Current %s is: %s' % (items[select][1], items[select][1], control.infoLabel('Container.ListItem.Art(discart)')), 1)
				show_artwork_window(imdb=imdb, tmdb=tmdb, tvdb=tvdb, mediatype=mediatype, heading=heading, artworktype=str(items[select][1]), title=control.infoLabel('Container.ListItem.Title'))
			if items[select][1] == 'keyart':
				heading = str(items[select][1] ) + ' artwork for: %s' % control.infoLabel('Container.ListItem.Title')
				log_utils.log('Umbrella Customize Art "%s" Selected. Current %s is: %s' % (items[select][1], items[select][1], control.infoLabel('Container.ListItem.Art(keyart)')), 1)
				show_artwork_window(imdb=imdb, tmdb=tmdb, tvdb=tvdb, mediatype=mediatype, heading=heading, artworktype=str(items[select][1]), title=control.infoLabel('Container.ListItem.Title'))
			if items[select][0].startswith('Add'): refresh = False
			control.hide()
			if refresh: control.refresh()
			control.trigger_widget_refresh()
	except:
		log_utils.error()
		control.hide()

def show_artwork_window(**kwargs):
	mediatype = kwargs.get('mediatype', '')
	heading = kwargs.get('heading', 'Umbrella Art')
	artworkType = kwargs.get('artworktype', '')
	imdb = kwargs.get('imdb','')
	tmdb = kwargs.get('tmdb', '')
	tvdb = kwargs.get('tvdb','')
	season = kwargs.get('season','')
	episode = kwargs.get('episode','')
	title = kwargs.get('title')
	try:
		control.busy()
		items = get_artwork(imdb=imdb, tmdb=tmdb, tvdb=tvdb, season=season, episode=episode, mediatype=mediatype, artwork_type=artworkType)
		if not items: return control.notification(title, 'No %s artwork found.' % artworkType)
		resetItem = {'artworkType': items[0]['artworkType'], 'source': 'Reset to Default', 'url': ''}
		items.append(resetItem)
		control.hide()
		itemsDumped = jsdumps(items)
		from resources.lib.windows.artselection import ArtSelect
		window = ArtSelect('artwork.xml', control.addonPath(control.addonId()), mediatype=mediatype, heading=heading, items=itemsDumped)
		selected_items = window.run()
		del window
		if selected_items or selected_items == 0:
			selectedUrl = items[selected_items].get('url')
			if mediatype == 'show' and selectedUrl == '': delete_artwork_one_item(media_type=mediatype, artworkType=artworkType, imdb=imdb, tvdb=tvdb)
			if mediatype == 'movie' and selectedUrl == '': delete_artwork_one_item(media_type=mediatype, artworkType=artworkType, imdb=imdb)
			if mediatype == 'show':
				add_show_entry(artworkType=artworkType,media_type=mediatype, imdb=imdb, tmdb=tmdb, tvdb=tvdb, season=season, episode=episode, url=selectedUrl)
			if mediatype == 'movie':
				add_movie_entry(artworkType=artworkType,media_type=mediatype, imdb=imdb, tmdb=tmdb, tvdb=tvdb, season=season, episode=episode, url=selectedUrl)
			if control.setting('debug.level') == '1':
				from resources.lib.modules import log_utils
				log_utils.log('selected item: %s' % str(items[selected_items]), 1)
		control.hide()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		control.hide()

def get_artwork(**kwargs):
	arttype = kwargs.get('mediatype')
	if arttype == 'movie':
		artworkList = []
		from resources.lib.indexers import fanarttv
		fanartList = fanarttv.FanartTv().get_all_movie_art(imdb=kwargs.get('imdb',''), tmdb=kwargs.get('tmdb',''), artwork_type=kwargs.get('artwork_type'))
		if fanartList and fanartList != '404:NOT FOUND':
			artworkList.extend(fanartList)
		from resources.lib.indexers import tmdb
		tmdbList = tmdb.Movies().get_all_movie_art(imdb=kwargs.get('imdb',''), tmdb=kwargs.get('tmdb',''), artwork_type=kwargs.get('artwork_type'))
		if tmdbList:
			artworkList.extend(tmdbList)
		return artworkList
	if arttype == 'show':
		artworkList = []
		from resources.lib.indexers import fanarttv
		fanartList = fanarttv.FanartTv().get_all_show_art(imdb=kwargs.get('imdb',''), tmdb=kwargs.get('tmdb',''), tvdb=kwargs.get('tvdb',''), artwork_type=kwargs.get('artwork_type'))
		if fanartList and fanartList != '404:NOT FOUND':
			artworkList.extend(fanartList)
		from resources.lib.indexers import tmdb
		tmdbList = tmdb.TVshows().get_all_show_art(imdb=kwargs.get('imdb',''), tmdb=kwargs.get('tmdb',''), tvdb=kwargs.get('tvdb',''), artwork_type=kwargs.get('artwork_type'))
		if tmdbList:
			artworkList.extend(tmdbList)
		return artworkList

	else:
		pass
	return type

def delete_artwork(**kwargs):
	if kwargs.get('media_type') == 'movie':
		try:
			dbcon = get_connection()
			dbcur = get_connection_cursor(dbcon)
			ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name=?;''', ('movies',)).fetchone()
			if not ck_table:
				dbcur.execute('''CREATE TABLE IF NOT EXISTS %s (imdb TEXT, tmdb TEXT, poster TEXT, fanart TEXT, landscape TEXT, banner TEXT, clearart TEXT, clearlogo TEXT, discart TEXT, keyart TEXT, UNIQUE(imdb));''' % 'movies')
				dbcur.connection.commit()
			try:
				imdb = kwargs.get('imdb','')
				dbcur.execute("DELETE FROM movies WHERE imdb = ?;", (imdb,))
			except Exception as e:
				log_utils.log("Exception: %s" % (str(e)), 1)  # Log the problematic item
			dbcur.connection.commit()
		except:
			log_utils.error()
		finally:
			dbcur.close() ; dbcon.close()
	elif kwargs.get('media_type') == 'show':
		try:
			dbcon = get_connection()
			dbcur = get_connection_cursor(dbcon)
			ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name=?;''', ('shows',)).fetchone()
			if not ck_table:
				dbcur.execute('''CREATE TABLE IF NOT EXISTS %s (imdb TEXT, tmdb TEXT, tvdb TEXT, poster TEXT, fanart TEXT, landscape TEXT, banner TEXT, clearart TEXT, clearlogo TEXT, season TEXT, episode TEXT, UNIQUE(imdb));''' % 'movies')
				dbcur.connection.commit()
			try:
				imdb = kwargs.get('imdb','')
				dbcur.execute("DELETE FROM shows WHERE imdb = ?;", (imdb,))
			except Exception as e:
				log_utils.log("Exception: %s" % (str(e)), 1)  # Log the problematic item
			dbcur.connection.commit()
		except:
			log_utils.error()
		finally:
			dbcur.close() ; dbcon.close()
	else:
		pass


def delete_artwork_one_item(**kwargs):
	if kwargs.get('media_type') == 'movie':
		try:
			dbcon = get_connection()
			dbcur = get_connection_cursor(dbcon)
			ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name=?;''', ('movies',)).fetchone()
			if not ck_table:
				dbcur.execute('''CREATE TABLE IF NOT EXISTS %s (imdb TEXT, tmdb TEXT, poster TEXT, fanart TEXT, landscape TEXT, banner TEXT, clearart TEXT, clearlogo TEXT, discart TEXT, keyart TEXT, UNIQUE(imdb));''' % 'movies')
				dbcur.connection.commit()
			try:
				imdb = kwargs.get('imdb','')
				artworkType = kwargs.get('artwork_type')
				dbcur.execute(f"UPDATE movies SET {artworkType} = NULL WHERE imdb = ?;", (imdb,))
			except Exception as e:
				log_utils.log("Exception: %s" % (str(e)), 1)  # Log the problematic item
			dbcur.connection.commit()
		except:
			log_utils.error()
		finally:
			dbcur.close() ; dbcon.close()
	elif kwargs.get('media_type') == 'show':
		try:
			dbcon = get_connection()
			dbcur = get_connection_cursor(dbcon)
			ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name=?;''', ('shows',)).fetchone()
			if not ck_table:
				dbcur.execute('''CREATE TABLE IF NOT EXISTS %s (imdb TEXT, tmdb TEXT, tvdb TEXT, poster TEXT, fanart TEXT, landscape TEXT, banner TEXT, clearart TEXT, clearlogo TEXT, season TEXT, episode TEXT, UNIQUE(imdb));''' % 'shows')
				dbcur.connection.commit()
			try:
				imdb = kwargs.get('imdb','')
				artworkType = kwargs.get('artwork_type')
				dbcur.execute(f"UPDATE shows SET {artworkType} = NULL WHERE imdb = ?;", (imdb,))
			except Exception as e:
				log_utils.log("Exception: %s" % (str(e)), 1)  # Log the problematic item
			dbcur.connection.commit()
		except:
			log_utils.error()
		finally:
			dbcur.close() ; dbcon.close()

def add_movie_entry(**kwargs):
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name=?;''', ('movies',)).fetchone()
		if not ck_table:
			dbcur.execute('''CREATE TABLE IF NOT EXISTS %s (imdb TEXT, tmdb TEXT, poster TEXT, fanart TEXT, landscape TEXT, banner TEXT, clearart TEXT, clearlogo TEXT, discart TEXT, keyart TEXT, UNIQUE(imdb));''' % 'movies')
			dbcur.connection.commit()
		try:
			imdb = kwargs.get('imdb','')
			artworkType =  kwargs.get('artworkType','')
			url = kwargs.get('url','')
			dbcur.execute(f'''INSERT INTO movies (imdb, {artworkType}) Values (?, ?) ON CONFLICT(imdb) DO UPDATE SET {artworkType} = excluded.{artworkType}''', (imdb, url))
		except Exception as e:
			log_utils.log("Exception: %s" % (str(e)), 1)  # Log the problematic item
		dbcur.connection.commit()
	except:
		log_utils.error()
	finally:
		dbcur.close() ; dbcon.close()

def add_show_entry(**kwargs):
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name=?;''', ('shows',)).fetchone()
		if not ck_table:
			dbcur.execute('''CREATE TABLE IF NOT EXISTS %s (imdb TEXT, tmdb TEXT, tvdb TEXT, poster TEXT, fanart TEXT, landscape TEXT, banner TEXT, clearart TEXT, clearlogo TEXT, season TEXT, episode TEXT, UNIQUE(imdb));''' % 'shows')
			dbcur.connection.commit()
		try:
			imdb = kwargs.get('imdb','')
			artworkType =  kwargs.get('artworkType','')
			url = kwargs.get('url','')
			dbcur.execute(f'''INSERT INTO shows (imdb, {artworkType}) Values (?, ?) ON CONFLICT(imdb) DO UPDATE SET {artworkType} = excluded.{artworkType}''', (imdb, url))
		except Exception as e:
			log_utils.log("Exception: %s" % (str(e)), 1)  # Log the problematic item
		dbcur.connection.commit()
	except:
		log_utils.error()
	finally:
		dbcur.close() ; dbcon.close()

def get_connection(setRowFactory=False):
	if not existsPath(dataPath): makeFile(dataPath)
	dbcon = db.connect(artworkFile, timeout=60)
	dbcon.execute('''PRAGMA page_size = 32768''')
	dbcon.execute('''PRAGMA journal_mode = OFF''')
	dbcon.execute('''PRAGMA synchronous = OFF''')
	dbcon.execute('''PRAGMA temp_store = memory''')
	dbcon.execute('''PRAGMA mmap_size = 30000000000''')
	if setRowFactory: dbcon.row_factory = _dict_factory
	return dbcon

def get_connection_cursor(dbcon):
	dbcur = dbcon.cursor()
	return dbcur

def _dict_factory(cursor, row):
	d = {}
	for idx, col in enumerate(cursor.description): d[col[0]] = row[idx]
	return d
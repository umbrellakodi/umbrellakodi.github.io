# -*- coding: utf-8 -*-
"""
	Umbrella Add-on
"""

from hashlib import md5
from threading import Thread
from json import dumps as jsdumps, loads as jsloads
from sys import argv
from sqlite3 import dbapi2 as database
from urllib.parse import unquote
import xbmc
from resources.lib.database.cache import clear_local_bookmarks
from resources.lib.database.metacache import fetch as fetch_metacache
from resources.lib.database.traktsync import fetch_bookmarks
from resources.lib.database import simklsync
from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import playcount
from resources.lib.modules import trakt
from resources.lib.modules import simkl
from resources.lib.modules import mdblist
from resources.lib.modules import customtrakt
from resources.lib.modules import floppy
from resources.lib.modules import scrob
from resources.lib.modules import punchplay
from resources.lib.modules import opensubs
from difflib import SequenceMatcher
from resources.lib.modules.source_utils import seas_ep_filter
from urllib.request import urlopen, Request
import fnmatch
import os
import re
import time

LOGINFO = 1
getLS = control.lang
getSetting = control.setting
homeWindow = control.homeWindow
playerWindow = control.playerWindow


def _remote_playback_enabled(scrobble_source, provider_source, markwatched_setting):
	"""Local resume tracking does not send remote progress/scrobble events."""
	return (scrobble_source != '0'
		and (scrobble_source == provider_source or getSetting(markwatched_setting) == 'true'))


def _mdblist_restore_started(since):
	"""Give Kodi's return-to-directory reload a chance before queuing another."""
	from urllib.parse import urlsplit, parse_qsl
	def is_progress():
		path = control.infoLabel('Container.FolderPath')
		return (urlsplit(path).netloc == 'plugin.video.umbrella'
			and dict(parse_qsl(urlsplit(path).query)).get('action') == 'mdblist_calendar')
	if not is_progress(): return False
	for _ in range(40):
		try: started = float(homeWindow.getProperty('umbrella.mdb.build_started') or 0)
		except (ValueError, TypeError): started = 0
		if started >= since:
			control.log_refresh_diagnostic('post-playback-refresh-skipped-mdb-reloading')
			return True
		# An existing populated directory still needs the explicit watched refresh.
		if control.infoLabel('Container.NumItems') not in ('', '0'): return False
		if control.monitor.waitForAbort(0.25): return True
		if not is_progress(): return True # user navigated away while waiting
	return False # no automatic reload appeared; retain the explicit fallback


def _refresh_after_player_closes(request_id, watched_update_thread=None):
	"""Refresh only after Kodi has restored the underlying window."""
	try:
		refresh_started = time.time()
		control.log_refresh_diagnostic('post-playback-worker-start', 'worker=%s' % request_id)
		# used to detect when the full screen playback window has been destroyed.
		for _ in range(20):
			if (not control.player.isPlaying()
					and not control.condVisibility('Window.IsActive(fullscreenvideo)')):
				break
			if control.monitor.waitForAbort(0.25): return
		else:
			log_utils.log('post-playback refresh abandoned: player window did not close', level=log_utils.LOGDEBUG)
			return
		for _ in range(20):
			if 'plugin.video.umbrella' in control.infoLabel('Container.PluginName'):
				break
			if control.monitor.waitForAbort(0.25): return
		else:
			log_utils.log('post-playback container refresh skipped: Umbrella directory was not restored', level=log_utils.LOGDEBUG)
			return
		# Episode watch-history updates run off the player callback thread. Do not
		# rebuild the directory until the provider write and indicator sync finish.
		if watched_update_thread and watched_update_thread.is_alive():
			watched_update_thread.join(20)
			if watched_update_thread.is_alive():
				log_utils.log('post-playback refresh continuing after watched update timeout', level=log_utils.LOGWARNING)
		if _mdblist_restore_started(refresh_started): return
		if control.monitor.waitForAbort(0.5): return
		if homeWindow.getProperty('umbrella.container_refresh_request') != request_id:
			control.log_refresh_diagnostic('post-playback-worker-superseded', 'worker=%s' % request_id)
			return
		control.log_refresh_diagnostic('post-playback-worker-dispatch', 'worker=%s' % request_id)
		homeWindow.clearProperty('umbrella.container_refresh_request')
		homeWindow.clearProperty('umbrella.playback_cleanup')
		homeWindow.clearProperty('umbrella.widget_refresh_pending')
		log_utils.log('container.refresh issued after player window closed', level=log_utils.LOGDEBUG)
		control.refresh()
	except: log_utils.error()
	finally:
		# Do not leave refreshes disabled if Kodi aborts or never restores the
		# directory. A newer playback request owns a different request id.
		if homeWindow.getProperty('umbrella.container_refresh_request') == request_id:
			homeWindow.clearProperty('umbrella.container_refresh_request')
			homeWindow.clearProperty('umbrella.playback_cleanup')


class Player(xbmc.Player):
	def __init__(self):
		xbmc.Player.__init__(self)
		self.play_next_triggered = False
		self.preScrape_triggered = False
		self.playbackStopped_triggered = False
		self.playback_resumed = False
		self.onPlayBackStopped_ran = False
		self.scrobble_sent = False
		self.scrobble_sent = False
		self.av_started_ran = False
		self._playback_path = None
		self.media_type = None
		self.DBID = None
		self.offset = '0'
		self.media_length = 0
		self.current_time = 0
		self.meta = {}
		self.enable_playnext = getSetting('enable.playnext') == 'true'
		self.playnext_time = int(getSetting('playnext.time')) or 60
		self.playnext_percentage = int(getSetting('playnext.percent')) or 80
		self.markwatched_percentage = int(getSetting('markwatched.percent')) or 85
		self.watched_during_playback = False
		self.watched_update_thread = None
		self.traktCredentials = trakt.getTraktCredentialsInfo()
		self.simklCredentials = simkl.getSimKLCredentialsInfo()
		self.mdblistCredentials = mdblist.getMDBListCredentialsInfo()
		self.customCredentials = customtrakt.getCustomCredentialsInfo()
		self.floppyCredentials = floppy.getFloppyCredentialsInfo()
		self.scrobCredentials = scrob.getScrobCredentialsInfo()
		self.punchplayCredentials = punchplay.getPunchPlayCredentialsInfo()
		self._scrob_heartbeat_at = 0
		self._punchplay_heartbeat_at = 0
		self.prefer_tmdbArt = getSetting('prefer.tmdbArt') == 'true'
		self.subtitletime = None
		self.debuglog = getSetting('debug.enabled') == 'true' and getSetting('debug.level') == '1'
		self.multi_season = getSetting('umbrella.multiSeason') == 'true'
		self.playnext_method = getSetting('playnext.method')
		self.playnext_theme = getSetting('playnext.theme')
		self.playnext_min = getSetting('playnext.min.seconds')
		self.skip_intro_enabled = getSetting('skip.intro.enable') == 'true'
		self.skip_recap_enabled = getSetting('skip.recap.enable') == 'true'
		self.skip_intro = None
		self.skip_recaps = []
		self.segment_credits = None
		self.segment_lookup_complete = False
		self.skip_intro_prompted = False
		self.skip_recaps_prompted = set()
		self.skip_intro_lookup_started = False
		self.custom_rewatch = False
		playerWindow.setProperty('umbrella.playnextPlayPressed', str(0))

	def play_source(self, title, year, season, episode, imdb, tmdb, tvdb, url, meta, debridPackCall=False):
		
		#if self.debuglog:
			#try:
				#log_utils.log('play_source Title: %s Type: %s' % (str(title), type(title)), level=log_utils.LOGDEBUG)
				#log_utils.log('play_source Year: %s Type: %s' % (str(year), type(year)), level=log_utils.LOGDEBUG)
				#log_utils.log('play_source Season: %s Type: %s' % (str(season), type(season)), level=log_utils.LOGDEBUG)
				#log_utils.log('play_source Episode: %s Type: %s' % (str(episode), type(episode)), level=log_utils.LOGDEBUG)
				#log_utils.log('play_source IMDB: %s Type: %s TMDB: %s Type: %s TVDB: %s Type: %s' % (str(imdb), type(imdb), str(tmdb), type(tmdb), str(tvdb), type(tvdb)), level=log_utils.LOGDEBUG)
				#log_utils.log('play_source URL: %s Type: %s' % (str(url), type(url)), level=log_utils.LOGDEBUG)
				#log_utils.log('play_source Meta: %s Type: %s' % (str(self.meta), type(self.meta)), level=log_utils.LOGDEBUG)
			#except:
				#log_utils.error()
		try:
			from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
			if not url: raise Exception
			# if self.debuglog:
			# 	log_utils.log('Play Source Received title: %s year: %s metatype: %s' % (title, year, type(meta)), level=log_utils.LOGDEBUG)
			self.media_type = 'movie' if season is None or episode is None else 'episode'
			self.title, self.year = title, str(year)
			if self.media_type == 'movie':
				self.name, self.season, self.episode = '%s (%s)' % (title, self.year), None, None
			
			elif self.media_type == 'episode':
				self.name, self.season, self.episode = '%s S%02dE%02d' % (title, int(season), int(episode)), '%01d' % int(season), '%01d' % int(episode)
			self.imdb, self.tmdb, self.tvdb = imdb or '', tmdb or '', tvdb or ''
			self.ids = {'imdb': self.imdb, 'tmdb': self.tmdb, 'tvdb': self.tvdb}
## - compare meta received to database and use largest(eventually switch to a request to fetch missing db meta for item)
			self.imdb_user = getSetting('imdbuser').replace('ur', '')
			self.tmdb_key = getSetting('tmdb.apikey')
			if not self.tmdb_key: self.tmdb_key = 'edde6b5e41246ab79a2697cd125e1781'
			self.tvdb_key = getSetting('tvdb.apikey')
			if self.media_type == 'episode': self.user = str(self.imdb_user) + str(self.tvdb_key)
			else: self.user = str(self.tmdb_key)
			self.lang = control.apiLanguage()['tvdb']
			meta1 = dict((k, v) for k, v in iter(meta.items()) if v is not None and v != '') if meta else None
			meta2 = fetch_metacache([{'imdb': self.imdb, 'tmdb': self.tmdb, 'tvdb': self.tvdb}], self.lang, self.user)[0]
			if meta2 != self.ids: meta2 = dict((k, v) for k, v in iter(meta2.items()) if v is not None and v != '')
			if meta1 is not None:
				try:
					if len(meta2) > len(meta1):
						meta2.update(meta1)
						meta = meta2
					else: meta = meta1
				except: log_utils.error()
			else: meta = meta2 if meta2 != self.ids else meta1
##################
			self.poster = meta.get('poster') if meta else ''
			self.fanart = meta.get('fanart') if meta else ''
			self.meta = meta
			poster, thumb, season_poster, fanart, banner, clearart, clearlogo, discart, meta = self.getMeta(meta)
			try:
				bookmark = Bookmarks()
				# Kodi passes the result of its native Resume/Start from beginning
				# dialog as a fourth plugin argument. Respect it instead of displaying
				# Umbrella's legacy bookmark dialog a second time.
				kodi_resume = None
				if len(argv) > 3 and str(argv[3]).lower() in ('resume:true', 'resume:false'):
					kodi_resume = str(argv[3]).lower() == 'resume:true'
				self.offset = bookmark.get(name=self.name, imdb=imdb, tmdb=tmdb, tvdb=tvdb, season=season, episode=episode, year=self.year, runtime=meta.get('duration') if meta else 0, kodi_resume=kodi_resume)
				self.custom_rewatch = bookmark.custom_rewatch
			except:
				if self.debuglog:
					log_utils.log('Get offset failed in player play_source name:%s imdb: %s tmdb: %s tvdb: %s' % (str(self.name), imdb, tmdb, tvdb),1)
				self.offset = '0'
			if self.offset == '-1':
				if self.debuglog:
					log_utils.log('User requested playback cancel', level=log_utils.LOGDEBUG)
				control.notification(message=32328)
				return control.cancelPlayback()
			item = control.item(path=url)
			#item.setUniqueIDs(self.ids) #changed for kodi20 setinfo method
			setUniqueIDs = self.ids #changed for kodi20 setinfo method
			if self.media_type == 'episode':
				item.setArt({'tvshow.clearart': clearart, 'tvshow.clearlogo': clearlogo, 'tvshow.discart': discart, 'thumb': thumb, 'tvshow.poster': season_poster, 'season.poster': season_poster, 'tvshow.fanart': fanart})
			else:
				item.setArt({'clearart': clearart, 'clearlogo': clearlogo, 'discart': discart, 'thumb': thumb, 'poster': poster, 'fanart': fanart})
			#if 'castandart' in meta: item.setCast(meta.get('castandart', '')) #changed for kodi20 setinfo method
			#item.setInfo(type='video', infoLabels=control.metadataClean(meta))
			control.set_info(item, meta, setUniqueIDs=setUniqueIDs, fileNameandPath=url) #changed for kodi20 setinfo method

			item.setProperty('IsPlayable', 'true')
			playlistAdded = self.checkPlaylist(item)
			if debridPackCall: 
				control.player.play(url, item) # seems this is only way browseDebrid pack files will play and have meta marked as watched
				if self.debuglog:
					log_utils.log('debridPackCallPlayed file as player.play', level=log_utils.LOGDEBUG)
			else:
				if playlistAdded:
					control.player.play(control.playlist)
				else:
					control.resolve(int(argv[1]), True, item)
				if self.media_type == 'episode' and self.enable_playnext: self.addEpisodetoPlaylist()
				if self.debuglog:
					log_utils.log('Played file as resolve.', level=log_utils.LOGDEBUG)
			homeWindow.setProperty('script.trakt.ids', jsdumps(self.ids))
			self.keepAlive()
			homeWindow.clearProperty('script.trakt.ids')
		except:
			log_utils.error()
			return control.cancelPlayback()

	def addEpisodetoPlaylist(self):
		try:
			from resources.lib.menus import seasons, episodes
			if self.debuglog: log_utils.log('addEpisodetoPlaylist: starting for "%s" S%sE%s tmdb=%s imdb=%s multi_season=%s' % (self.meta.get('tvshowtitle', ''), self.season, self.episode, self.tmdb, self.imdb, self.multi_season), level=log_utils.LOGDEBUG)
			seasons_list = seasons.Seasons().tmdb_list(tvshowtitle='', imdb='', tmdb=self.tmdb, tvdb='', art=None)
			if not seasons_list:
				if self.debuglog: log_utils.log('addEpisodetoPlaylist: tmdb_list returned empty/None for tmdb=%s' % self.tmdb, level=log_utils.LOGWARNING)
				return
			season_nums = []
			for s in seasons_list:
				if isinstance(s, dict):
					val = s.get('season')
					try:
						if val is not None:
							season_nums.append(int(val))
					except (TypeError, ValueError):
						continue
			if self.debuglog: log_utils.log('addEpisodetoPlaylist: found seasons %s' % season_nums, level=log_utils.LOGDEBUG)
			show_meta = dict(self.meta)
			try:
				series_rating = next(float(s.get('rating') or 0) for s in seasons_list if float(s.get('rating') or 0) > 0)
				show_meta['rating'] = series_rating
			except: pass
			ep_data = [episodes.Episodes().get(self.meta.get('tvshowtitle'), self.meta.get('year'), self.imdb, self.tmdb, self.tvdb, show_meta, season=i, create_directory=False) for i in season_nums]
			items = [i for e in ep_data for i in e if isinstance(i, dict) and i.get('unaired') != 'true']
			if self.debuglog: log_utils.log('addEpisodetoPlaylist: total aired episodes across all seasons: %s' % len(items), level=log_utils.LOGDEBUG)
			if not items:
				if self.debuglog: log_utils.log('addEpisodetoPlaylist: episode list is empty - cannot add next episode', level=log_utils.LOGWARNING)
				return
			if self.season is None or self.episode is None:
				if self.debuglog: log_utils.log('addEpisodetoPlaylist: season or episode is None (season=%s episode=%s)' % (self.season, self.episode), level=log_utils.LOGWARNING)
				return
			try:
				season_int = int(self.season)
				episode_int = int(self.episode)
			except (TypeError, ValueError):
				if self.debuglog: log_utils.log('addEpisodetoPlaylist: cannot convert season/episode to int (season=%s episode=%s)' % (self.season, self.episode), level=log_utils.LOGWARNING)
				return
			def safe_int(val):
				try:
					return int(val)
				except (TypeError, ValueError):
					return None
			index = None
			for idx, i in enumerate(items):
				if not isinstance(i, dict):
					continue
				s_val = i.get('season') if isinstance(i, dict) else None
				e_val = i.get('episode') if isinstance(i, dict) else None
				s_int = safe_int(s_val)
				e_int = safe_int(e_val)
				if s_int is not None and e_int is not None and s_int == season_int and e_int == episode_int:
					index = idx
					break
			if index is None:
				if self.debuglog: log_utils.log('addEpisodetoPlaylist: current episode S%sE%s not found in items list (total items: %s)' % (season_int, episode_int, len(items)), level=log_utils.LOGWARNING)
				return
			if self.debuglog: log_utils.log('addEpisodetoPlaylist: found current episode at index %s of %s' % (index, len(items)), level=log_utils.LOGDEBUG)
			if index + 1 >= len(items):
				if self.debuglog: log_utils.log('addEpisodetoPlaylist: no next episode after S%sE%s (last in list)' % (season_int, episode_int), level=log_utils.LOGWARNING)
				return
			item = items[index+1]
			if not isinstance(item, dict):
				if self.debuglog: log_utils.log('addEpisodetoPlaylist: next item is not a dict', level=log_utils.LOGWARNING)
				return
			item_season = safe_int(item.get('season')) if isinstance(item, dict) else None
			if item_season is None:
				if self.debuglog: log_utils.log('addEpisodetoPlaylist: next item has no season value', level=log_utils.LOGWARNING)
				return
			if item_season > season_int and not self.multi_season:
				if self.debuglog: log_utils.log('addEpisodetoPlaylist: next episode is S%sE%s but multi_season is disabled - not adding to playlist' % (item_season, item.get('episode')), level=log_utils.LOGWARNING)
				return
			try:
				current_pos = control.playlist.getposition()
				if current_pos != -1 and control.playlist.size() > current_pos + 1:
					if self.debuglog: log_utils.log('addEpisodetoPlaylist: playlist already has an item queued at position %s (size=%s) - not adding a duplicate' % (current_pos + 1, control.playlist.size()), level=log_utils.LOGDEBUG)
					return
			except: pass
			playlist_items = episodes.Episodes().episodeDirectory([item], next=False, playlist=True)
			added = False
			for url, li, folder in playlist_items:
				if url and li:
					control.playlist.add(url=url, listitem=li)
					added = True
					if self.debuglog: log_utils.log('addEpisodetoPlaylist: successfully added S%sE%s to playlist (playlist size now: %s)' % (item.get('season'), item.get('episode'), control.playlist.size()), level=log_utils.LOGDEBUG)
			if not added:
				if self.debuglog: log_utils.log('addEpisodetoPlaylist: episodeDirectory returned no valid items for S%sE%s' % (item.get('season'), item.get('episode')), level=log_utils.LOGWARNING)
		except Exception:
			log_utils.error()

	def getMeta(self, meta):
		try:
			if not meta or not isinstance(meta, dict) or ('videodb' in control.infoLabel('ListItem.FolderPath')): raise Exception()
			#
			def getDBID(meta):
				try:
					if self.media_type == 'movie':
						meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "originaltitle", "uniqueid", "year", "premiered", "genre", "studio", "country", "runtime", "rating", "votes", "mpaa", "director", "writer", "cast", "plot", "plotoutline", "tagline", "thumbnail", "art", "file"]}, "id": 1}' % (self.year, str(int(self.year) + 1), str(int(self.year) - 1)))
						meta = jsloads(meta)['result']['movies']
						try:
							meta = [i for i in meta if (isinstance(i, dict) and ((i.get('uniqueid', {}).get('imdb', '') == self.imdb) or (i.get('uniqueid', {}).get('unknown', '') == self.imdb)))] # scraper now using "unknown"
						except:
							if self.debuglog:
								log_utils.log('Get Meta Failed in getMeta: %s' % str(meta), level=log_utils.LOGDEBUG)
							meta = None
						if meta: meta = meta[0]
						else: raise Exception()
						return meta.get('movieid')
					if self.media_type == 'episode':
						show_meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "originaltitle", "uniqueid", "mpaa", "year", "genre", "runtime", "thumbnail", "file"]}, "id": 1}' % (self.year, str(int(self.year)+1), str(int(self.year)-1)))
						show_meta = jsloads(show_meta)['result']['tvshows']
						show_meta = [i for i in show_meta if isinstance(i, dict) and ((i.get('uniqueid', {}).get('imdb', '') == self.imdb) or (i.get('uniqueid', {}).get('unknown', '') == self.imdb))]
						if show_meta: show_meta = show_meta[0]
						else: raise Exception()
						tvshowid = show_meta['tvshowid']
						if tvshowid:
							dbidmetameta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params":{"tvshowid": %d, "filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["showtitle", "title", "season", "episode", "firstaired", "runtime", "rating", "director", "writer", "cast", "plot", "thumbnail", "art", "file"]}, "id": 1}' % (tvshowid, self.season, self.episode))
							dbidmetameta = jsloads(dbidmetameta)['result']['episodes']
						if dbidmetameta: meta = dbidmetameta[0]
						else: raise Exception()
						return meta.get('episodeid')
				except:
					log_utils.error()
					return None
			poster = meta.get('poster3') or meta.get('poster2') or meta.get('poster') #poster2 and poster3 may not be passed anymore
			thumb = meta.get('thumb')
			thumb = thumb or poster or control.addonThumb()
			season_poster = meta.get('season_poster') or poster
			fanart = meta.get('fanart')
			banner = meta.get('banner')
			clearart = meta.get('clearart')
			clearlogo = meta.get('clearlogo')
			discart = meta.get('discart')
			if 'mediatype' not in meta:
				meta.update({'mediatype': 'episode' if self.episode else 'movie'})
				if self.episode: meta.update({'tvshowtitle': self.title, 'season': self.season, 'episode': self.episode})
			self.DBID = getDBID(meta)
			return (poster, thumb, season_poster, fanart, banner, clearart, clearlogo, discart, meta)
		except Exception:
			log_utils.error()
		try:
			def cleanLibArt(art):
				if not art: return ''
				art = unquote(art.replace('image://', ''))
				if art.endswith('/'): art = art[:-1]
				return art
			def sourcesDirMeta(metadata): # pass player minimal meta needed from lib pull
				if not metadata: return metadata
				allowed = ['mediatype', 'imdb', 'tmdb', 'tvdb', 'poster', 'season_poster', 'fanart', 'banner', 'clearart', 'clearlogo', 'discart', 'thumb', 'title', 'tvshowtitle', 'year', 'premiered', 'rating', 'plot', 'duration', 'mpaa', 'season', 'episode', 'castandrole']
				return {k: v for k, v in iter(metadata.items()) if k in allowed}
			poster, thumb, season_poster, fanart, banner, clearart, clearlogo, discart, meta = '', '', '', '', '', '', '', '', {'title': self.name}
			if self.media_type != 'movie': raise Exception()
			# do not add IMDBNUMBER as tmdb scraper puts their id in the key value
			meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "originaltitle", "uniqueid", "year", "premiered", "genre", "studio", "country", "runtime", "rating", "votes", "mpaa", "director", "writer", "cast", "plot", "plotoutline", "tagline", "thumbnail", "art", "file"]}, "id": 1}' % (self.year, str(int(self.year) + 1), str(int(self.year) - 1)))
			meta = jsloads(meta)['result']['movies']
			try:
				meta = [i for i in meta if (i.get('uniqueid', []).get('imdb', '') == self.imdb) or (i.get('uniqueid', []).get('unknown', '') == self.imdb)] # scraper now using "unknown"
			except:
				if self.debuglog:
					log_utils.log('Get Meta Failed in getMeta: %s' % str(meta), level=log_utils.LOGDEBUG)
				meta = None
			if meta: meta = meta[0]
			else: raise Exception()
			if 'mediatype' not in meta: meta.update({'mediatype': 'movie'})
			if 'duration' not in meta: meta.update({'duration': meta.get('runtime')}) # Trakt scrobble resume needs this for lib playback
			if 'castandrole' not in meta: meta.update({'castandrole': [(i['name'], i['role']) for i in meta.get('cast')]})
			thumb = cleanLibArt(meta.get('art').get('thumb', ''))
			poster = cleanLibArt(meta.get('art').get('poster', '')) or self.poster
			fanart = cleanLibArt(meta.get('art').get('fanart', '')) or self.fanart
			banner = cleanLibArt(meta.get('art').get('banner', '')) # not sure this is even used by player
			clearart = cleanLibArt(meta.get('art').get('clearart', ''))
			clearlogo = cleanLibArt(meta.get('art').get('clearlogo', ''))
			discart = cleanLibArt(meta.get('art').get('discart'))
			if 'plugin' not in control.infoLabel('Container.PluginName'):
				self.DBID = meta.get('movieid')
			meta = sourcesDirMeta(meta)
			return (poster, thumb, '', fanart, banner, clearart, clearlogo, discart, meta)
		except: log_utils.error()
		try:
			if self.media_type != 'episode': raise Exception()
			# do not add IMDBNUMBER as tmdb scraper puts their id in the key value
			show_meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "originaltitle", "uniqueid", "mpaa", "year", "genre", "runtime", "thumbnail", "file"]}, "id": 1}' % (self.year, str(int(self.year)+1), str(int(self.year)-1)))
			show_meta = jsloads(show_meta)['result']['tvshows']
			show_meta = [i for i in show_meta if i['uniqueid']['imdb'] == self.imdb]
			show_meta = [i for i in show_meta if (i.get('uniqueid', []).get('imdb', '') == self.imdb) or (i.get('uniqueid', []).get('unknown', '') == self.imdb)] # scraper now using "unknown"
			if show_meta: show_meta = show_meta[0]
			else: raise Exception()
			tvshowid = show_meta['tvshowid']
			meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params":{"tvshowid": %d, "filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["showtitle", "title", "season", "episode", "firstaired", "runtime", "rating", "director", "writer", "cast", "plot", "thumbnail", "art", "file"]}, "id": 1}' % (tvshowid, self.season, self.episode))
			meta = jsloads(meta)['result']['episodes']
			if meta: meta = meta[0]
			else: raise Exception()
			if 'mediatype' not in meta: meta.update({'mediatype': 'episode'})
			if 'tvshowtitle' not in meta: meta.update({'tvshowtitle': meta.get('showtitle')})
			if 'castandrole' not in meta: meta.update({'castandrole': [(i['name'], i['role']) for i in meta.get('cast')]})
			if 'genre' not in meta: meta.update({'genre': show_meta.get('genre')})
			if 'duration' not in meta: meta.update({'duration': meta.get('runtime')}) # Trakt scrobble resume needs this for lib playback but Kodi lib returns "0" for shows or episodes
			if 'mpaa' not in meta: meta.update({'mpaa': show_meta.get('mpaa')})
			if 'premiered' not in meta: meta.update({'premiered': meta.get('firstaired')})
			if 'year' not in meta: meta.update({'year': show_meta.get('year')}) # shows year not year episode aired
			thumb = cleanLibArt(meta.get('art').get('thumb', ''))
			season_poster = poster = cleanLibArt(meta.get('art').get('season.poster', '')) or self.poster
			fanart = cleanLibArt(meta.get('art').get('tvshow.fanart', '')) or self.poster
			banner = cleanLibArt(meta.get('art').get('tvshow.banner', '')) # not sure this is even used by player
			clearart = cleanLibArt(meta.get('art').get('tvshow.clearart', ''))
			clearlogo = cleanLibArt(meta.get('art').get('tvshow.clearlogo', ''))
			discart = cleanLibArt(meta.get('art').get('discart'))
			if 'plugin' not in control.infoLabel('Container.PluginName'):
				self.DBID = meta.get('episodeid')
			meta = sourcesDirMeta(meta)
			return (poster, thumb, season_poster, fanart, banner, clearart, clearlogo, discart, meta)
		except:
			log_utils.error()
			return (poster, thumb, season_poster, fanart, banner, clearart, clearlogo, discart, meta)

	def checkPlaylist(self, item):
		#just checking here for an empty playlist.
		try:
			#check if no playlist is currently added.
			if control.playlist.getposition() == -1 and self.media_type == 'episode':
				control.player.stop()
				control.playlist.clear()
				if getSetting('play.mode.tv') == '0' and self.enable_playnext:
					# Source select + playnext: add directly without cancelPlayback() to avoid
					# resolve(False) on a stale handle triggering onPlayBackStopped and clearing the playlist
					try:
						episodelabel = '%sx%02d %s' % (int(self.season), int(self.episode), self.meta.get('title', ''))
						if self.meta.get('title'):
							item.setLabel(episodelabel)
						newurl = item.getVideoInfoTag().getFilenameAndPath()
						if newurl:
							control.playlist.add(url=newurl, listitem=item)
							return True
					except: pass
					return False
				return self.singleItemPlaylist(item)
			else:
				return False
		except:
			return False

	def singleItemPlaylist(self, item):
		log_utils.log('singleItemPlaylist() started.', level=log_utils.LOGDEBUG)
		try:
			control.cancelPlayback()
			episodelabel = '%sx%02d %s' % (int(self.season), int(self.episode), self.meta.get('title'))
			if self.meta.get('title'):
				item.setLabel(episodelabel)
			from sys import argv
			newurl = item.getVideoInfoTag().getFilenameAndPath()
			log_utils.log('singleItemPlaylist() url: %s' % str(newurl), level=log_utils.LOGDEBUG)
			control.playlist.add(url=newurl, listitem=item)
			log_utils.log('singleItemPlaylist() returning true.', level=log_utils.LOGDEBUG)
			return True
		except:
			log_utils.log('singleItemPlaylist() exception: returning false', level=log_utils.LOGDEBUG)
			return False

	def getWatchedPercent(self):
		try:
			if self.isPlayback():
				try:
					position = self.getTime()
					if position != 0: self.current_time = position
					total_length = self.getTotalTime()
					if total_length > 0: self.media_length = max(self.media_length, total_length)
				except: pass
			current_position = self.current_time
			#log_utils.log('getWatchedPercent() current_position: %s' % current_position, level=log_utils.LOGDEBUG)
			total_length = self.media_length
			#log_utils.log('getWatchedPercent() total_length: %s' % total_length, level=log_utils.LOGDEBUG)
			watched_percent = 0
			if int(total_length) != 0:
				try:
					watched_percent = float(current_position) / float(total_length) * 100
					if watched_percent > 100: watched_percent = 100
				except: log_utils.error()
			return watched_percent
		except:
			log_utils.error()
			return 0

	def getRemainingTime(self):
		remaining_time = 0
		if self.isPlayback():
			try:
				current_position = self.getTime()
				remaining_time = int(self.media_length) - int(current_position)
			except: pass
		return remaining_time

	def keepAlive(self):
		control.hide()
		control.sleep(200)
		pname = '%s.player.overlay' % control.addonInfo('id')
		homeWindow.clearProperty(pname)
		for i in range(0, 500):
			if self.isPlayback():
				# skip closeAll when window_monitor owns the source dialog — avoids "Window id does not exist" crash in skins with timers (e.g. Arctic Fuse 2)
				if homeWindow.getProperty('umbrella.window_keep_alive') != 'true':
					control.closeAll()
				break
			if self.onPlayBackStopped_ran:
				return
			xbmc.sleep(200)

		xbmc.sleep(5000)
		playlist_skip = False
		try: running_path = self.getPlayingFile() # original video that playlist playback started with
		except: running_path = ''
		if (self.media_type == 'episode' and running_path
				and (self.skip_intro_enabled or self.skip_recap_enabled or self.playnext_method == '3')):
			self._start_skip_intro_lookup(running_path)
		if playerWindow.getProperty('umbrella.playlistStart_position'): pass
		else:
			if control.playlist.size() > 1: playerWindow.setProperty('umbrella.playlistStart_position', str(control.playlist.getposition()))

		while self.isPlayingVideo() and not control.monitor.abortRequested():
			try:
				if running_path != self.getPlayingFile(): # will not match if user hits "Next" so break from keepAlive()
					playlist_skip = True
					break

				try:
					self.current_time = self.getTime()
					_total = self.getTotalTime()
					if _total > 0: self.media_length = max(self.media_length, _total)
				except: pass
				self._maybe_show_skip_intro(running_path)
				self._maybe_show_skip_recap(running_path)
				try:

					scrobble_source = getSetting('scrobble.source')
					if self.scrobCredentials and _remote_playback_enabled(scrobble_source, '6', 'scrob.markwatched'):
						if self.current_time - self._scrob_heartbeat_at >= 30:
							self._scrob_heartbeat_at = self.current_time
							heartbeat_percent = round((self.current_time / self.media_length) * 100, 2) if self.media_length else 0
							Thread(target=scrob.scrobbleProgress, kwargs={
								'media_type': self.media_type, 'imdb': self.imdb, 'tmdb': self.tmdb, 'tvdb': self.tvdb,
								'season': self.season, 'episode': self.episode, 'watched_percent': heartbeat_percent,
								'current_time': self.current_time, 'total_time': self.media_length}).start()
					if self.punchplayCredentials and _remote_playback_enabled(scrobble_source, '7', 'punchplay.markwatched'):
						if self.current_time - self._punchplay_heartbeat_at >= 30:
							self._punchplay_heartbeat_at = self.current_time
							heartbeat_percent = round((self.current_time / self.media_length) * 100, 2) if self.media_length else 0
							Thread(target=punchplay.scrobbleProgress, kwargs={
								'media_type': self.media_type, 'imdb': self.imdb, 'tmdb': self.tmdb, 'tvdb': self.tvdb,
								'season': self.season, 'episode': self.episode, 'watched_percent': heartbeat_percent,
								'current_time': self.current_time, 'total_time': self.media_length}).start()
				except: pass
				watcher = (self.getWatchedPercent() >= int(self.markwatched_percentage))
				property = homeWindow.getProperty(pname)

				if self.media_type == 'movie':
					try:
						if watcher and property != '5':
							homeWindow.setProperty(pname, '5')
							if self.debuglog:
								log_utils.log('Sending Movie to be marked as watched. IMDB: %s Title: %s Watch Percentage Used: %s Current Percentage: %s' % (self.imdb, self.title, self.markwatched_percentage, self.getWatchedPercent()), level=log_utils.LOGDEBUG)
							playcount.markMovieDuringPlayback(self.imdb, '5')
							self.watched_during_playback = True
					except: pass
					xbmc.sleep(2000)
				elif self.media_type == 'episode':
					try:
						if watcher and property != '5':
							homeWindow.setProperty(pname, '5')
							if self.debuglog:
								log_utils.log('Sending Episode to be marked as watched. IMDB: %s TVDB: %s Season: %s Episode: %s Title: %s Watch Percentage Used: %s Current Percentage: %s' % (self.imdb, self.tvdb, self.season, self.episode, self.title, self.markwatched_percentage, self.getWatchedPercent()), level=log_utils.LOGDEBUG)
							self.watched_update_thread = Thread(target=playcount.markEpisodeDuringPlayback, args=(self.imdb, self.tvdb, self.season, self.episode, '5'))
							self.watched_update_thread.start()
							self.watched_during_playback = True
						if self.enable_playnext and not self.play_next_triggered:
							playlist_size = int(control.playlist.size())
							if playlist_size > 1:
								if self.preScrape_triggered == False:
									xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=play_preScrapeNext)')
									self.preScrape_triggered = True
								remaining_time = self.getRemainingTime()
								if self.playnext_method== '0':
									if remaining_time < (self.playnext_time + 1) and remaining_time > 0:
										if self.debuglog:
											log_utils.log('Playnext triggered by method time. IMDB: %s Title: %s Time Used: %s Remaining Time: %s' % (self.imdb, self.title, self.playnext_time, remaining_time), level=log_utils.LOGDEBUG)
										xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=play_nextWindowXML)')
										self.play_next_triggered = True
								elif self.playnext_method== '1':
									if self.getWatchedPercent() >= int(self.playnext_percentage) and remaining_time >= 0:
										if self.debuglog:
											log_utils.log('Playnext triggered by method percentage. IMDB: %s Title: %s Percentage Used: %s Current Percentage: %s' % (self.imdb, self.title, self.playnext_percentage, self.getWatchedPercent()), level=log_utils.LOGDEBUG)
										xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=play_nextWindowXML)')
										self.play_next_triggered = True
								elif self.playnext_method== '2':
									if self.subtitletime is None:
										self.subtitletime = Subtitles().downloadForPlayNext(self.title, self.year, self.imdb, self.season, self.episode, self.media_length)
									if str(self.subtitletime) == 'default':
										if getSetting('playnext.sub.backupmethod')== '0': #subtitle failed use seconds as backup
											subtitletimeumb = int(getSetting('playnext.sub.seconds'))
											if remaining_time < (subtitletimeumb + 1) and remaining_time > 0:
												if self.debuglog:
													log_utils.log('Playnext triggered by method subtitle backup. IMDB: %s Title: %s Time Used: %s Current Time: %s' % (self.imdb, self.title, subtitletimeumb, remaining_time), level=log_utils.LOGDEBUG)
												xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=play_nextWindowXML)')
												self.play_next_triggered = True
										elif getSetting('playnext.sub.backupmethod') == '1': #subtitle failed use percentage as backup
											subtitletimeumb = int(getSetting('playnext.sub.percent'))
											if self.getWatchedPercent() >= int(subtitletimeumb) and remaining_time > 0:
												if self.debuglog:
													log_utils.log('Playnext triggered by method subtitle backup. IMDB: %s Title: %s Percent Used: %s Current Percent: %s' % (self.imdb, self.title, subtitletimeumb, self.getWatchedPercent()), level=log_utils.LOGDEBUG)
												xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=play_nextWindowXML)')
												self.play_next_triggered = True
									elif self.subtitletime != None and str(self.subtitletime) != 'default':
										if int(self.subtitletime) < 0:
											#negative time for subtitles
											self.subtitletime = int(getSetting('playnext.sub.seconds'))
										if int(self.subtitletime > 600 ):
											#subtitle time is greater than 10 minutes we need to use the default now.
											log_utils.log('Playnext triggered by method subtitle but the time is over 10 minutes. IMDB: %s Title: %s Time Attempting to Use Was: %s Changed to: %s Current Time: %s' % (self.imdb, self.title, self.subtitletime, int(getSetting('playnext.sub.seconds')), remaining_time), level=log_utils.LOGDEBUG)
											self.subtitletime = int(getSetting('playnext.sub.seconds'))
										if (remaining_time < (int(self.subtitletime) + 1) or remaining_time < int(self.playnext_min)) and remaining_time > 0:
											if self.debuglog:
													log_utils.log('Playnext triggered by method subtitle. IMDB: %s Title: %s Subtitle Time Used: %s Current Time: %s' % (self.imdb, self.title, self.subtitletime, remaining_time), level=log_utils.LOGDEBUG)
											xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=play_nextWindowXML)')
											self.play_next_triggered = True
									else:
										log_utils.error()
								elif self.playnext_method == '3':
									fallback = int(getSetting('playnext.segment.fallback')) or 60
									at_credits = self.segment_credits is not None and self.current_time >= self.segment_credits
									no_data_fallback = (self.segment_lookup_complete and self.segment_credits is None
											and remaining_time <= fallback)
									if (at_credits or no_data_fallback) and remaining_time > 0:
										if self.debuglog:
											log_utils.log('Playnext triggered by online credits timestamp (credits=%s, fallback=%s)' % (self.segment_credits, fallback), level=log_utils.LOGDEBUG)
										xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=play_nextWindowXML)')
										self.play_next_triggered = True
								else:
									if self.debuglog:
										log_utils.log('No match found for playnext method.', level=log_utils.LOGDEBUG)
					except: log_utils.error()
					xbmc.sleep(1000)

			except:
				log_utils.error()
				xbmc.sleep(1000)
		homeWindow.clearProperty(pname)
		if playlist_skip:
			if not self.scrobble_sent:
				self._sendFinishedItemState()
		else:
			if not self.scrobble_sent:
				self.playbackStopped_triggered = True
				self.onPlayBackStopped()

	def _start_skip_intro_lookup(self, running_path):
		if self.skip_intro_lookup_started: return
		self.skip_intro_lookup_started = True
		def lookup():
			try:
				from resources.lib.indexers.segments import SegmentScraper
				intro, recaps, credits = SegmentScraper(self.imdb, self.tmdb, self.season, self.episode).run()
				if self.isPlayingVideo() and self.getPlayingFile() == running_path:
					if self.skip_intro_enabled: self.skip_intro = intro
					if self.skip_recap_enabled: self.skip_recaps = recaps
					self.segment_credits = credits
					if self.debuglog:
						log_utils.log('Playback segments: intro=%s recaps=%s credits=%s' % (intro, recaps, credits), level=log_utils.LOGDEBUG)
			except Exception:
				log_utils.error()
			finally:
				if self.isPlayingVideo() and self.getPlayingFile() == running_path:
					self.segment_lookup_complete = True
		thread = Thread(target=lookup)
		thread.daemon = True
		thread.start()

	def _maybe_show_skip_intro(self, running_path):
		if self.skip_intro_prompted or not self.skip_intro: return
		intro_start, intro_end = self.skip_intro
		if self.current_time > intro_end:
			self.skip_intro_prompted = True
			return
		if self.current_time < intro_start: return
		if self._show_skip_segment(running_path, intro_end, 40813):
			self.skip_intro_prompted = True

	def _maybe_show_skip_recap(self, running_path):
		if not self.skip_recaps: return
		for index, recap in enumerate(self.skip_recaps):
			if index in self.skip_recaps_prompted: continue
			recap_start, recap_end = recap
			if self.current_time > recap_end:
				self.skip_recaps_prompted.add(index)
				continue
			if self.current_time < recap_start: return
			if self._show_skip_segment(running_path, recap_end, 40820):
				self.skip_recaps_prompted.add(index)
			return

	def _show_skip_segment(self, running_path, segment_end, label_id):
		if playerWindow.getProperty('umbrella.skipintro.dialog') == 'true': return False
		playerWindow.setProperty('umbrella.skipintro.dialog', 'true')
		def show_dialog():
			try:
				from resources.lib.windows.skip_intro import SkipSegmentXML
				skip_window = 'skip_intro.xml'
				if self.playnext_theme == '1': skip_window = 'skip_intro_ah.xml'
				elif self.playnext_theme == '2': skip_window = 'skip_intro_aura.xml'
				elif self.playnext_theme == '3': skip_window = 'skip_intro_ah_compact.xml'
				window = SkipSegmentXML(skip_window, control.addonPath(control.addonId()),
						playing_file=running_path, segment_end=segment_end, label_id=label_id)
				window.doModal()
				del window
			except Exception:
				log_utils.error()
			finally:
				playerWindow.clearProperty('umbrella.skipintro.dialog')
		thread = Thread(target=show_dialog)
		thread.daemon = True
		thread.start()
		return True
			
	def isPlayingFile(self):
		if self._running_path is None or self._running_path.startswith("plugin://"):
			return False

	def isPlayback(self):
		# Kodi often starts playback where isPlaying() is true and isPlayingVideo() is false, since the video loading is still in progress, whereas the play is already started.
		try:
			playing = self.isPlaying()
		except:
			playing = False
		try:
			playingvideo = self.isPlayingVideo()
		except:
			playingvideo = False
		try:
			playTime = self.getTime() >= 0
		except:
			playTime = False
		#log_utils.log('isPlayBack Call isPlaying: %s isPlayingVideo: %s self.getTime: %s' % (playing, playingvideo, playTime))
		return playing and playingvideo and playTime

	def libForPlayback(self):
		if not self.DBID: return
		try:
			if self.media_type == 'movie':
				rpc = '{"jsonrpc": "2.0", "method": "VideoLibrary.SetMovieDetails", "params": {"movieid": %s, "playcount": 1 }, "id": 1 }' % str(self.DBID)
			elif self.media_type == 'episode':
				rpc = '{"jsonrpc": "2.0", "method": "VideoLibrary.SetEpisodeDetails", "params": {"episodeid": %s, "playcount": 1 }, "id": 1 }' % str(self.DBID)
			control.jsonrpc(rpc)
		except: log_utils.error()

### Kodi player callback methods ###
	def onAVStarted(self): 
		# Each resolved playlist item has its own Player. Kodi can deliver the
		# next item's callbacks to the previous instance while it is finishing.
		if self.av_started_ran or self.media_type is None: return
		try: self._playback_path = self.getPlayingFile()
		except: pass
		playerWindow.clearProperty('umbrella.playnext.transition')
		self.watched_during_playback = False
		self.watched_update_thread = None
		self.scrobble_sent = False
		self.scrobble_sent = False
		self.onPlayBackStopped_ran = False
		# Initialize tracking for this resolved item only.
		self.av_started_ran = False
		self.playback_resumed = False
		self._scrob_heartbeat_at = 0
		self._punchplay_heartbeat_at = 0
		self.play_next_triggered = False
		self.preScrape_triggered = False
		self.subtitletime = None
		# Segment data belongs to the episode that just started. Player instances
		# survive playlist transitions, so retaining these values can make a prior
		# episode's failed lookup force the fallback on every following episode.
		self.skip_intro = None
		self.skip_recaps = []
		self.segment_credits = None
		self.segment_lookup_complete = False
		self.skip_intro_prompted = False
		self.skip_recaps_prompted = set()
		self.skip_intro_lookup_started = False
		#control.sleep(200)
		homeWindow.clearProperty('umbrella.window_keep_alive')
		for i in range(0, 500):
			if self.onPlayBackStopped_ran or self.scrobble_sent: return
			if self.isPlayback():
				#control.closeAll() #i cannot remember what this was for.
				break
			else: control.sleep(200)
		if self.offset != '0' and self.playback_resumed is False:
			control.sleep(200)
			_resume_source = getSetting('scrobble.source')
			if self.traktCredentials and _resume_source == '1': # re-adjust the resume point since dialog is based on meta runtime vs. getTotalTime() and inaccurate
				try:
					total_time = self.getTotalTime()
					progress = float(fetch_bookmarks(self.imdb, self.tmdb, self.tvdb, self.season, self.episode))
					self.offset = (progress / 100) * total_time
				except: pass
			elif self.simklCredentials and _resume_source == '2':
				try:
					total_time = self.getTotalTime()
					progress = float(simklsync.fetch_bookmarks(self.imdb, self.tmdb, self.tvdb, self.season, self.episode))
					self.offset = (progress / 100) * total_time
				except: pass
			elif self.mdblistCredentials and _resume_source == '3':
				try:
					from resources.lib.database import mdbsync
					total_time = self.getTotalTime()
					progress = float(mdbsync.fetch_bookmarks(self.imdb, self.tmdb, self.tvdb, self.season, self.episode))
					self.offset = (progress / 100) * total_time
				except: pass
			elif self.customCredentials and _resume_source == '4':
				try:
					from resources.lib.database import customtraktsync
					total_time = self.getTotalTime()
					progress = float(customtraktsync.fetch_bookmarks(self.imdb, self.tmdb, self.tvdb, self.season, self.episode))
					self.offset = (progress / 100) * total_time
				except: pass
			elif self.floppyCredentials and _resume_source == '5':
				try:
					from resources.lib.database import floppysync
					total_time = self.getTotalTime()
					progress = float(floppysync.fetch_bookmarks(self.imdb, self.tmdb, self.tvdb, self.season, self.episode))
					self.offset = (progress / 100) * total_time
				except: pass
			elif self.scrobCredentials and _resume_source == '6':
				try:
					from resources.lib.database import scrobsync
					total_time = self.getTotalTime()
					progress = float(scrobsync.fetch_bookmarks(self.imdb, self.tmdb, self.tvdb, self.season, self.episode))
					self.offset = (progress / 100) * total_time
				except: pass
			elif self.punchplayCredentials and _resume_source == '7':
				try:
					from resources.lib.database import punchplaysync
					total_time = self.getTotalTime()
					resume_item = punchplay.get_resume_item(self.tmdb, self.season, self.episode)
					if resume_item: self.offset = resume_item['position_seconds']
				except: pass
			try:
				self.seekTime(self.offset)
			except:
				log_utils.log('Exception trying to seekTime() offset: %s'% self.offset, level=log_utils.LOGDEBUG)
			self.playback_resumed = True
		if getSetting('subtitles') == 'true': Subtitles().get(self.title, self.year, self.imdb, self.season, self.episode)
		if self.onPlayBackStopped_ran or self.scrobble_sent or not self.isPlayingVideo(): return
		try:
			self.current_time = self.getTime()
			self.media_length = self.getTotalTime()
		except: pass
		if not self.av_started_ran:
			self.av_started_ran = True
			scrobble_source = getSetting('scrobble.source')
			if (self.custom_rewatch and self.customCredentials and self.media_type == 'episode'
					and _remote_playback_enabled(scrobble_source, '4', 'custom.markwatched')):
				# A deliberate replay starts a new watch cycle. Remove completed history now;
				# crossing the normal watched threshold will add it again during playback.
				customtrakt.markEpisodeAsNotWatched(self.imdb, self.tvdb, self.season, self.episode)
				self.custom_rewatch = False
			try: _start_percent = round((float(self.offset) / self.getTotalTime()) * 100, 2) if self.playback_resumed and self.getTotalTime() > 0 else 0
			except: _start_percent = 0
			if self.traktCredentials and _remote_playback_enabled(scrobble_source, '1', 'trakt.markwatched'):
				trakt.scrobbleReset(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, refresh=False) # refresh issues container.refresh()
				trakt.scrobbleStart(media_type=self.media_type, title=self.title, tvshowtitle=self.title, year=self.year, imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, watched_percent=_start_percent)
			if self.simklCredentials and _remote_playback_enabled(scrobble_source, '2', 'simkl.markwatched'):
				simkl.scrobbleReset(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, refresh=False)
				simkl.scrobbleStart(media_type=self.media_type, title=self.title, tvshowtitle=self.title, year=self.year, imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, watched_percent=_start_percent)
			if self.mdblistCredentials and _remote_playback_enabled(scrobble_source, '3', 'mdblist.markwatched'):
				mdblist.scrobbleStart(media_type=self.media_type, title=self.title, tvshowtitle=self.title, year=self.year, imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, watched_percent=_start_percent)
			if self.customCredentials and _remote_playback_enabled(scrobble_source, '4', 'custom.markwatched'):
				customtrakt.scrobbleReset(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, refresh=False)
				customtrakt.scrobbleStart(media_type=self.media_type, title=self.title, tvshowtitle=self.title, year=self.year, imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, watched_percent=_start_percent)
			if self.floppyCredentials and not floppy.isReadOnly() and _remote_playback_enabled(scrobble_source, '5', 'floppy.markwatched'):
				floppy.scrobbleReset(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, refresh=False, remote=False)
				floppy.scrobbleStart(media_type=self.media_type, title=self.title, tvshowtitle=self.title, year=self.year, imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, watched_percent=_start_percent, current_time=(self.offset if self.playback_resumed else 0), total_time=self.getTotalTime())
			if self.scrobCredentials and _remote_playback_enabled(scrobble_source, '6', 'scrob.markwatched'):
				scrob.scrobbleReset(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, refresh=False, remote=False)
				scrob.scrobbleStart(media_type=self.media_type, title=self.title, tvshowtitle=self.title, year=self.year, imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, watched_percent=_start_percent, current_time=(self.offset if self.playback_resumed else 0), total_time=self.getTotalTime(), resumed=self.playback_resumed)
			if self.punchplayCredentials and _remote_playback_enabled(scrobble_source, '7', 'punchplay.markwatched'):
				punchplay.scrobbleStart(media_type=self.media_type, title=self.title, tvshowtitle=self.title, year=self.year, imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, watched_percent=_start_percent, current_time=(self.offset if self.playback_resumed else 0), total_time=self.getTotalTime())
		log_utils.log('onAVStarted callback', level=log_utils.LOGDEBUG)

	def onPlayBackStarted(self):
		control.hide() #this is new.

	def onPlayBackSeek(self, time, seekOffset):
		seekOffset /= 1000

	def onPlayBackSeekChapter(self, chapter):
		log_utils.log('onPlayBackSeekChapter callback', level=log_utils.LOGDEBUG)

	def onQueueNextItem(self):
		log_utils.log('onQueueNextItem callback', level=log_utils.LOGDEBUG)

	def _sendFinishedItemState(self):
		Bookmarks().reset(self.current_time, self.media_length, self.name, self.year)
		self.scrobble_sent = True
		self.scrobble_sent = True
		_scrobble_source = getSetting('scrobble.source')
		if self.traktCredentials and _remote_playback_enabled(_scrobble_source, '1', 'trakt.markwatched'):
			Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, already_watched=self.watched_during_playback)
		if self.simklCredentials and _remote_playback_enabled(_scrobble_source, '2', 'simkl.markwatched'):
			Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, service='simkl', title=self.title, year=self.year, already_watched=self.watched_during_playback)
		if self.mdblistCredentials and _remote_playback_enabled(_scrobble_source, '3', 'mdblist.markwatched'):
			Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, service='mdblist', title=self.title, tvshowtitle=self.title, year=self.year, already_watched=self.watched_during_playback)
		if self.customCredentials and _remote_playback_enabled(_scrobble_source, '4', 'custom.markwatched'):
			Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, service='custom', title=self.title, tvshowtitle=self.title, year=self.year, already_watched=self.watched_during_playback)
		if self.floppyCredentials and not floppy.isReadOnly() and _remote_playback_enabled(_scrobble_source, '5', 'floppy.markwatched'):
			Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, service='floppy', title=self.title, tvshowtitle=self.title, year=self.year, already_watched=self.watched_during_playback)
		if self.scrobCredentials and _remote_playback_enabled(_scrobble_source, '6', 'scrob.markwatched'):
			Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, service='scrob', title=self.title, tvshowtitle=self.title, year=self.year, already_watched=self.watched_during_playback)
		if self.punchplayCredentials and _remote_playback_enabled(_scrobble_source, '7', 'punchplay.markwatched'):
			Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, service='punchplay', title=self.title, tvshowtitle=self.title, year=self.year, already_watched=self.watched_during_playback)
		watcher = self.getWatchedPercent()
		seekable = (int(self.current_time) > 180 and (watcher < int(self.markwatched_percentage)))
		# Remote services can retain progress before Umbrella's three-minute local
		# bookmark cutoff. Custom/ScrobbleSync accepts any positive progress; the
		# other percentage-based resume sources become visible from two percent.
		remote_resume_saved = (_scrobble_source == '4' and watcher > 0
				or _scrobble_source in ('1', '2', '3', '5', '6', '7') and watcher >= 2)
		resume_available = ((seekable or remote_resume_saved)
				and watcher < int(self.markwatched_percentage))
		if watcher >= int(self.markwatched_percentage):
			self.libForPlayback() # only write playcount to local lib
			if _scrobble_source == '0':
				if getSetting('localnotify') == 'true': control.notification(title=self.title, message=getLS(35510))
				if not self.watched_during_playback:
					# Watched history is independent of the resume/scrobble source.
					if self.media_type == 'episode':
						playcount.markEpisodeDuringPlayback(self.imdb, self.tvdb, self.season, self.episode, '5')
					elif self.media_type == 'movie':
						playcount.markMovieDuringPlayback(self.imdb, '5')
					self.watched_during_playback = True
				if self.imdb:
					from resources.lib.database import watchedcache as _wc
					_wc.delete_progress(self.media_type, self.imdb, self.tmdb or '', self.season or 0, self.episode or 0)
		elif seekable and _scrobble_source == '0' and self.imdb:
			from resources.lib.database import watchedcache as _wc
			_wc.save_progress(self.media_type, self.imdb, self.tmdb or '',
							  self.season or 0, self.episode or 0,
							  self.name, round(watcher, 2), self.current_time)
		return resume_available, _scrobble_source

	def onPlayBackStopped(self):
		try:
			playnext_transition = playerWindow.getProperty('umbrella.playnext.transition') == 'true'
			if not playnext_transition:
				playerWindow.clearProperty('umbrella.preResolved_nextUrl')
				playerWindow.clearProperty('umbrella.preResolved_season')
				playerWindow.clearProperty('umbrella.preResolved_episode')
				playerWindow.clearProperty('umbrella.preResolved_imdb')
				playerWindow.clearProperty('umbrella.playlistStart_position')
			homeWindow.clearProperty('umbrella.window_keep_alive')
			clear_local_bookmarks()
			try:
				current_pos = control.playlist.getposition()
				has_next_queued = current_pos != -1 and control.playlist.size() > current_pos + 1
			except:
				has_next_queued = False
			if not playnext_transition and not has_next_queued:
				control.playlist.clear()
			if (not self.onPlayBackStopped_ran or (self.playbackStopped_triggered and not self.onPlayBackStopped_ran)) and not self.scrobble_sent: # Kodi callback unreliable and often not issued
				self.onPlayBackStopped_ran = True
				self.playbackStopped_triggered = False
				# Every enabled tracking service may request a widget refresh while
				# _sendFinishedItemState runs. Block all of them until Kodi has restored
				# the directory; this applies equally to Custom, Trakt, Simkl, MDBList,
				# Floppy and Scrob progress sources.
				homeWindow.setProperty('umbrella.playback_cleanup', 'true')
				seekable, _scrobble_source = self._sendFinishedItemState()
				# Never refresh from inside this callback. Kodi has not necessarily restored
				# the underlying directory yet, so even one Container.Refresh here can reuse
				# a closing plugin handle and produce an empty or duplicated listing.
				# A newly saved resume point must be reflected by the directory even when
				# the optional general-purpose container refresh setting is disabled.
				if ((getSetting('crefresh') == 'true' or seekable) and not playnext_transition
						and not has_next_queued):
					request_id = str(time.time_ns())
					homeWindow.setProperty('umbrella.container_refresh_request', request_id)
					refresh_thread = Thread(target=_refresh_after_player_closes, args=(request_id, self.watched_update_thread))
					refresh_thread.daemon = True
					refresh_thread.start()
				else:
					homeWindow.clearProperty('umbrella.playback_cleanup')
				#control.trigger_widget_refresh() # skinshortcuts handles widget refresh
				#control.checkforSkin(action='off')
				try:
					from resources.lib.modules import tools
					tools.delete_all_subs()
				except:
					log_utils.error()
				log_utils.log('onPlayBackStopped callback', level=log_utils.LOGDEBUG)
		except:
			homeWindow.clearProperty('umbrella.playback_cleanup')
			log_utils.error()

	def onPlayBackEnded(self):
		try:
			# A delayed end event from the previous playlist item can arrive after
			# this item's AVStarted. Do not close the session still playing here.
			if self._playback_path and self.isPlayingVideo():
				try:
					if self.getPlayingFile() == self._playback_path:
						log_utils.log('Ignoring previous playlist item end callback during active playback', level=log_utils.LOGDEBUG)
						return
				except: pass
			if getSetting('crefresh') == 'true': homeWindow.setProperty('umbrella.playback_cleanup', 'true')
			Bookmarks().reset(self.current_time, self.media_length, self.name, self.year)
			self.libForPlayback()
			_scrobble_source = getSetting('scrobble.source')
			if not self.scrobble_sent:
				self.scrobble_sent = True
				self.scrobble_sent = True
				if self.traktCredentials and _remote_playback_enabled(_scrobble_source, '1', 'trakt.markwatched'):
					Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, already_watched=self.watched_during_playback)
				if self.simklCredentials and _remote_playback_enabled(_scrobble_source, '2', 'simkl.markwatched'):
					Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, service='simkl', title=self.title, year=self.year, already_watched=self.watched_during_playback)
				if self.mdblistCredentials and _remote_playback_enabled(_scrobble_source, '3', 'mdblist.markwatched'):
					Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, service='mdblist', title=self.title, tvshowtitle=self.title, year=self.year, already_watched=self.watched_during_playback)
				if self.customCredentials and _remote_playback_enabled(_scrobble_source, '4', 'custom.markwatched'):
					Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, service='custom', title=self.title, tvshowtitle=self.title, year=self.year, already_watched=self.watched_during_playback)
				if self.floppyCredentials and not floppy.isReadOnly() and _remote_playback_enabled(_scrobble_source, '5', 'floppy.markwatched'):
					Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, service='floppy', title=self.title, tvshowtitle=self.title, year=self.year, already_watched=self.watched_during_playback)
				if self.scrobCredentials and _remote_playback_enabled(_scrobble_source, '6', 'scrob.markwatched'):
					Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, service='scrob', title=self.title, tvshowtitle=self.title, year=self.year, already_watched=self.watched_during_playback)
				if self.punchplayCredentials and _remote_playback_enabled(_scrobble_source, '7', 'punchplay.markwatched'):
					Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, service='punchplay', title=self.title, tvshowtitle=self.title, year=self.year, already_watched=self.watched_during_playback)
			if _scrobble_source == '0':
				if getSetting('localnotify') == 'true': control.notification(title=self.title, message=getLS(35510))
				if not self.watched_during_playback and self.media_length > 0:
					_pct = float(self.current_time / self.media_length) * 100
					if _pct >= int(self.markwatched_percentage):
						# Watched history is independent of the resume/scrobble source.
						if self.media_type == 'episode':
							playcount.markEpisodeDuringPlayback(self.imdb, self.tvdb, self.season, self.episode, '5')
						elif self.media_type == 'movie':
							playcount.markMovieDuringPlayback(self.imdb, '5')
						self.watched_during_playback = True
				if self.imdb:
					from resources.lib.database import watchedcache as _wc
					_wc.delete_progress(self.media_type, self.imdb, self.tmdb or '', self.season or 0, self.episode or 0)
			try:
				playingfile = self.isPlaying()
			except:
				playingfile = False
			playlist_position = control.playlist.getposition()
			playlist_size = control.playlist.size()
			has_next_queued = playlist_position >= 0 and playlist_position + 1 < playlist_size
			log_utils.log('onPlayBackEnded Playlist Position: %s Playlist Count: %s Has Next: %s isPlaying: %s' % (playlist_position, playlist_size, has_next_queued, playingfile), level=log_utils.LOGDEBUG)
			# Kodi can briefly report position 0 with no active file between plugin
			# playlist items. Position 0 is not a reason to clear when position 1 is
			# the next episode; doing so breaks continuous playback after the second
			# episode even though the Play Next window found and displayed episode 3.
			if not playingfile and not has_next_queued and (playlist_size <= 1 or playlist_position >= playlist_size - 1):
				control.playlist.clear()
			if getSetting('crefresh') == 'true' and not has_next_queued:
				request_id = str(time.time_ns())
				homeWindow.setProperty('umbrella.container_refresh_request', request_id)
				refresh_thread = Thread(target=_refresh_after_player_closes, args=(request_id, self.watched_update_thread))
				refresh_thread.daemon = True
				refresh_thread.start()
			else:
				homeWindow.clearProperty('umbrella.playback_cleanup')
			log_utils.log('onPlayBackEnded callback', level=log_utils.LOGDEBUG)
			#control.checkforSkin(action='off')
		except: log_utils.error()

	def onPlayBackError(self):
		playerWindow.clearProperty('umbrella.playnext.transition')
		playerWindow.clearProperty('umbrella.preResolved_nextUrl')
		playerWindow.clearProperty('umbrella.playlistStart_position')
		homeWindow.clearProperty('umbrella.window_keep_alive')

		Bookmarks().reset(self.current_time, self.media_length, self.name, self.year)
		log_utils.error()
		log_utils.log('onPlayBackError callback', level=log_utils.LOGDEBUG)
		#control.checkforSkin(action='off')

	def onPlayBackPaused(self):
		log_utils.log('onPlayBackPaused callback', level=log_utils.LOGDEBUG)
		try:
			if self.watched_during_playback: return
			total_time = self.getTotalTime()
			if total_time <= 0: return
			pause_percent = round((self.getTime() / total_time) * 100, 2)
			scrobble_source = getSetting('scrobble.source')
			if self.traktCredentials and _remote_playback_enabled(scrobble_source, '1', 'trakt.markwatched'):
				if self.media_type == 'movie':
					trakt.scrobbleMovie(self.imdb, self.tmdb, pause_percent)
				else:
					trakt.scrobbleEpisode(self.imdb, self.tmdb, self.tvdb, self.season, self.episode, pause_percent)
			if self.simklCredentials and _remote_playback_enabled(scrobble_source, '2', 'simkl.markwatched'):
				if self.media_type == 'movie':
					simkl.scrobbleMovie(self.title, self.year, self.imdb, self.tmdb, pause_percent)
				else:
					simkl.scrobbleEpisode(self.title, self.year, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, pause_percent)
			if self.mdblistCredentials and _remote_playback_enabled(scrobble_source, '3', 'mdblist.markwatched'):
				if self.media_type == 'movie':
					mdblist.scrobbleMovie(self.title, self.year, self.imdb, self.tmdb, pause_percent)
				else:
					mdblist.scrobbleEpisode(self.title, self.year, self.imdb, self.tmdb, self.tvdb, self.season, self.episode, pause_percent)
			if self.customCredentials and _remote_playback_enabled(scrobble_source, '4', 'custom.markwatched'):
				if self.media_type == 'movie':
					customtrakt.scrobbleMovie(self.imdb, self.tmdb, pause_percent)
				else:
					customtrakt.scrobbleEpisode(self.imdb, self.tmdb, self.tvdb, self.season, self.episode, pause_percent)
			if self.floppyCredentials and not floppy.isReadOnly() and _remote_playback_enabled(scrobble_source, '5', 'floppy.markwatched'):
				if self.media_type == 'movie':
					floppy.scrobbleMovie(self.imdb, self.tmdb, pause_percent, current_time=self.getTime(), total_time=total_time)
				else:
					floppy.scrobbleEpisode(self.imdb, self.tmdb, self.tvdb, self.season, self.episode, pause_percent, current_time=self.getTime(), total_time=total_time)
			if self.scrobCredentials and _remote_playback_enabled(scrobble_source, '6', 'scrob.markwatched'):
				if self.media_type == 'movie':
					scrob.scrobbleMovie(self.imdb, self.tmdb, pause_percent, current_time=self.getTime(), total_time=total_time)
				else:
					scrob.scrobbleEpisode(self.imdb, self.tmdb, self.tvdb, self.season, self.episode, pause_percent, current_time=self.getTime(), total_time=total_time)
			if self.punchplayCredentials and _remote_playback_enabled(scrobble_source, '7', 'punchplay.markwatched'):
				if self.media_type == 'movie':
					punchplay.scrobbleMovie(self.imdb, self.tmdb, pause_percent, current_time=self.getTime(), total_time=total_time)
				else:
					punchplay.scrobbleEpisode(self.imdb, self.tmdb, self.tvdb, self.season, self.episode, pause_percent, current_time=self.getTime(), total_time=total_time)
		except RuntimeError:
			# Kodi may deliver the pause callback as playback is stopping, after the
			# player has already discarded its timing state.
			return
		except: log_utils.error()

	def onPlayBackResumed(self):
		log_utils.log('onPlayBackResumed callback', level=log_utils.LOGDEBUG)
		try:
			if self.watched_during_playback: return
			total_time = self.getTotalTime()
			if total_time <= 0: return
			resume_position = self.getTime() or self.current_time
			resume_percent = round((resume_position / total_time) * 100, 2)
			scrobble_source = getSetting('scrobble.source')
			if self.traktCredentials and _remote_playback_enabled(scrobble_source, '1', 'trakt.markwatched'):
				trakt.scrobbleStart(media_type=self.media_type, title=self.title, tvshowtitle=self.title, year=self.year, imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, watched_percent=resume_percent)
			if self.simklCredentials and _remote_playback_enabled(scrobble_source, '2', 'simkl.markwatched'):
				simkl.scrobbleStart(media_type=self.media_type, title=self.title, tvshowtitle=self.title, year=self.year, imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, watched_percent=resume_percent)
			if self.mdblistCredentials and _remote_playback_enabled(scrobble_source, '3', 'mdblist.markwatched'):
				mdblist.scrobbleStart(media_type=self.media_type, title=self.title, tvshowtitle=self.title, year=self.year, imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, watched_percent=resume_percent)
			if self.customCredentials and _remote_playback_enabled(scrobble_source, '4', 'custom.markwatched'):
				customtrakt.scrobbleStart(media_type=self.media_type, title=self.title, tvshowtitle=self.title, year=self.year, imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, watched_percent=resume_percent)
			if self.floppyCredentials and not floppy.isReadOnly() and _remote_playback_enabled(scrobble_source, '5', 'floppy.markwatched'):
				floppy.scrobbleStart(media_type=self.media_type, title=self.title, tvshowtitle=self.title, year=self.year, imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, watched_percent=resume_percent, current_time=resume_position, total_time=total_time)
			if self.scrobCredentials and _remote_playback_enabled(scrobble_source, '6', 'scrob.markwatched'):
				scrob.scrobbleStart(media_type=self.media_type, title=self.title, tvshowtitle=self.title, year=self.year, imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, watched_percent=resume_percent, current_time=resume_position, total_time=total_time, resumed=True)
			if self.punchplayCredentials and _remote_playback_enabled(scrobble_source, '7', 'punchplay.markwatched'):
				punchplay.scrobbleStart(media_type=self.media_type, title=self.title, tvshowtitle=self.title, year=self.year, imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb, season=self.season, episode=self.episode, watched_percent=resume_percent, current_time=resume_position, total_time=total_time, resumed=True)
		except: log_utils.error()

class PlayNext(xbmc.Player):
	def __init__(self):
		super(PlayNext, self).__init__()
		self.enable_playnext = getSetting('enable.playnext') == 'true'
		self.stillwatching_count = int(getSetting('stillwatching.count'))
		self.playing_file = None
		self.providercache_hours = int(getSetting('cache.providers'))
		self.debuglog = control.setting('debug.enabled') == 'true' and control.setting('debug.level') == '1'
		self.playnext_method = control.setting('playnext.method')
		self.playnext_theme = getSetting('playnext.theme')

	def display_xml(self):
		try:
			self.playing_file = self.getPlayingFile()
		except:
			log_utils.error("Kodi did not return a playing file, killing playnext xml's")
			return
		# Only show playnext if next episode meta is valid
		next_meta = self.getNext_meta() if control.playlist.size() > 0 and control.playlist.getposition() != (control.playlist.size() - 1) else None
		if next_meta:
			if self.isStill_watching(): target = self.show_stillwatching_xml
			elif self.enable_playnext: target = self.show_playnext_xml
			else: return
			if self.playing_file != self.getPlayingFile(): return
			if not self.isPlayingVideo(): return
			if not xbmc.getCondVisibility('Window.IsVisible(fullscreenvideo)'): return
			target()

	def isStill_watching(self):
		# still_watching = float(control.playlist.getposition() + 1) / self.stillwatching_count # this does not work if you start playback on a divisible position with "stillwatching_count"
		playlistStart_position = playerWindow.getProperty('umbrella.playlistStart_position')
		if playlistStart_position: still_watching = float(control.playlist.getposition() - int(playlistStart_position) + 1) / self.stillwatching_count
		else: still_watching = float(control.playlist.getposition() + 1) / self.stillwatching_count
		if still_watching == 0: return False
		return still_watching.is_integer()

	def getNext_meta(self):
		try:
			
			from urllib.parse import parse_qsl
			current_position = control.playlist.getposition()
			next_url = control.playlist[current_position + 1].getPath()
			# next_url=videodb://tvshows/titles/16/2/571?season=2&tvshowid=16 # library playback returns this
			params = dict(parse_qsl(next_url.replace('?', '')))
			#next_meta = jsloads(params.get('meta')) if params.get('meta') else '' # not available for library playback
			next_meta = {}
			#tmdbhelperbs
			if 'plugin.video.themoviedb.helper' in next_url and not control.addonInstalled('service.upnext'):
				tmdb = params.get('tmdb_id')
				helper_season = params.get('season')
				helper_episode = params.get('episode')
				from resources.lib.menus import seasons, episodes
				seasons = seasons.Seasons().tmdb_list(tvshowtitle='', imdb='', tmdb=tmdb, tvdb='', art=None)
				for season in seasons:
					if season.get('season') != helper_season: continue
					else: break
				items = episodes.Episodes().tmdb_list(tvshowtitle=season.get('tvshowtitle'), imdb=season.get('imdb'), tmdb=tmdb, tvdb=season.get('tvdb'), meta=season, season=helper_season)
				for item in items:
					if str(item.get('episode')) != helper_episode: continue #episode is a string.... important to note.
					else: break
				next_meta = {'tvshowtitle': item.get('tvshowtitle'), 'title': item.get('title'), 'year': item.get('year'), 'premiered': item.get('premiered'), 'season': helper_season, 'episode': helper_episode, 'imdb': item.get('imdb'),
									'tmdb': item.get('tmdb'), 'tvdb': item.get('tvdb'), 'rating': item.get('rating'), 'tvshow_rating': item.get('tvshow_rating'), 'landscape': '', 'fanart': item.get('fanart'), 'thumb': item.get('thumb'), 'duration': item.get('duration'), 'episode_type': item.get('episode_type')}
			elif 'plugin.video.umbrella' in next_url:
				next_meta = jsloads(params.get('meta')) if params.get('meta') else ''
			elif 'videob://' in next_url and not control.addonInstalled('service.upnext'):
				log_utils.log('Library not supported currently.', level=log_utils.LOGDEBUG)
			if next_meta:
				try: episode_rating = float(next_meta.get('rating') or 0)
				except: episode_rating = 0
				try: show_rating = float(next_meta.get('tvshow_rating') or 0)
				except: show_rating = 0
				rating = episode_rating if episode_rating > 0 else show_rating
				next_meta['rating'] = round(rating, 1) if rating > 0 else ''
		except:
			log_utils.error()
		return next_meta

	def show_playnext_xml(self):
		try:
			next_meta = self.getNext_meta()
			if not next_meta:
				log_utils.log('Next Meta Missing TMDB: %s Season: %s Episode: %s' % str(self.title, self.season, self.episode), level=log_utils.LOGDEBUG)
				raise Exception()
			#some changes here for playnext and themes.
			from resources.lib.windows.playnext import PlayNextXML
			if self.playnext_theme == '2'and control.skin in ('skin.auramod'):
				if self.debuglog:
					log_utils.log('Show Playnext Theme Netflix with Auramod Skin.', level=log_utils.LOGDEBUG)
				window = PlayNextXML('auraplaynext.xml', control.addonPath(control.addonId()), meta=next_meta)
			elif self.playnext_theme == '2'and control.skin not in ('skin.auramod'):
				if self.debuglog:
					log_utils.log('Show Playnext Theme Netflix No Aura.', level=log_utils.LOGDEBUG)
				window = PlayNextXML('auraplaynext2.xml', control.addonPath(control.addonId()), meta=next_meta)
			elif self.playnext_theme == '1':
				if self.debuglog:
					log_utils.log('Show Playnext Theme AH2.', level=log_utils.LOGDEBUG)
				window = PlayNextXML('ahplaynext3.xml', control.addonPath(control.addonId()), meta=next_meta)
			elif self.playnext_theme == '3':
				if self.debuglog:
					log_utils.log('Show Playnext Theme Arctic Fuse.', level=log_utils.LOGDEBUG)
				window = PlayNextXML('ahplaynext4.xml', control.addonPath(control.addonId()), meta=next_meta)
			else:
				if self.debuglog:
					log_utils.log('Show Playnext Theme Default Theme.', level=log_utils.LOGDEBUG)
				window = PlayNextXML('playnext.xml', control.addonPath(control.addonId()), meta=next_meta)
			window.run()
			del window
			self.play_next_triggered = True
		except:
			log_utils.error()
			self.play_next_triggered = True

	def show_stillwatching_xml(self):
		try:
			next_meta = self.getNext_meta()
			if not next_meta: raise Exception()
			if self.debuglog:
				log_utils.log('Show Playnext Still Watching.', level=log_utils.LOGDEBUG)
			from resources.lib.windows.playnext_stillwatching import StillWatchingXML
			if self.playnext_theme == '2'and control.skin in ('skin.auramod'):
				window = StillWatchingXML('auraplaynext_stillwatching.xml', control.addonPath(control.addonId()), meta=next_meta)
			elif self.playnext_theme == '2'and control.skin not in ('skin.auramod'):
				window = StillWatchingXML('auraplaynext_stillwatching2.xml', control.addonPath(control.addonId()), meta=next_meta)
			elif self.playnext_theme == '1':
				window = StillWatchingXML('ahplaynext_stillwatching3.xml', control.addonPath(control.addonId()), meta=next_meta)
			elif self.playnext_theme == '3':
				window = StillWatchingXML('ahplaynext_stillwatching4.xml', control.addonPath(control.addonId()), meta=next_meta)
			else:
				window = StillWatchingXML('playnext_stillwatching.xml', control.addonPath(control.addonId()), meta=next_meta)
			window.run()
			del window
			self.play_next_triggered = True
		except:
			log_utils.error()
			self.play_next_triggered = True

	def prescrapeNext(self):
		try:
			if getSetting('play.mode.tv') == '0': return
			playlist_pos = control.playlist.getposition()
			playlist_size = control.playlist.size()
			if playlist_size > 0 and playlist_pos != (playlist_size - 1):
				from resources.lib.modules import sources
				from resources.lib.database import providerscache
				next_meta=self.getNext_meta()
				if not next_meta:
					if self.debuglog: log_utils.log('prescrapeNext: next_meta is None - cannot prescrape', level=log_utils.LOGWARNING)
					raise Exception()
				title = next_meta.get('title')
				year = next_meta.get('year')
				imdb = next_meta.get('imdb')
				tmdb = next_meta.get('tmdb')
				tvdb = next_meta.get('tvdb')
				season = next_meta.get('season')
				episode = next_meta.get('episode')
				tvshowtitle = next_meta.get('tvshowtitle')
				premiered = next_meta.get('premiered')
				if self.debuglog: log_utils.log('prescrapeNext: scraping sources for "%s" S%sE%s' % (tvshowtitle, season, episode), level=log_utils.LOGDEBUG)
				next_sources = providerscache.get(sources.Sources().getSources, self.providercache_hours, title, year, imdb, tmdb, tvdb, str(season), str(episode), tvshowtitle, premiered, next_meta, True)
				if not self.isPlayingVideo():
					return playerWindow.clearProperty('umbrella.preResolved_nextUrl')
				sources.Sources().preResolve(next_sources, next_meta)
			else:
				if self.debuglog: log_utils.log('prescrapeNext: at end of playlist (size=%s pos=%s) - clearing preResolved' % (playlist_size, playlist_pos), level=log_utils.LOGWARNING)
				playerWindow.clearProperty('umbrella.preResolved_nextUrl')
		except:
			log_utils.error()
			playerWindow.clearProperty('umbrella.preResolved_nextUrl')


class Subtitles:
	def __init__(self):
		self.debuglog = control.setting('debug.enabled') == 'true' and control.setting('debug.level') == '1'
		self.playnext_method = getSetting('playnext.method')

	def _language_code(self, language):
		language = (language or '').strip().lower()
		if not language: return ''
		# Kodi may expose a name, ISO-639-1/2 code, or a decorated stream label.
		aliases = {'gre': 'ell', 'ger': 'deu', 'fre': 'fra', 'dut': 'nld', 'rum': 'ron', 'chi': 'zho', 'cze': 'ces', 'slo': 'slk'}
		for value in (language, re.split(r'[^a-z]+', language)[0]):
			try: code = xbmc.convertLanguage(value, xbmc.ISO_639_2).lower()
			except: code = value
			code = aliases.get(code, code)
			if len(code) == 3: return code
		return aliases.get(language[:3], language[:3])

	def _select_embedded(self, preferred_language):
		if getSetting('subtitles.prefer.embedded') != 'true': return False
		preferred_code = self._language_code(preferred_language)
		prefer_hi = getSetting('subtitles.prefer.hearing_impaired') == 'true'
		prefer_forced = getSetting('subtitles.prefer.forced') == 'true'
		# Some input streams report their tracks shortly after onAVStarted.
		for attempt in range(5):
			try: streams = xbmc.Player().getAvailableSubtitleStreams() or []
			except: streams = []
			matches = []
			for index, stream in enumerate(streams):
				if self._language_code(stream) != preferred_code: continue
				label = str(stream).lower()
				is_hi = any(token in label for token in ('hearing impaired', 'hearing-impaired', 'sdh', '[cc]', ' closed caption'))
				is_forced = 'forced' in label or 'foreign parts' in label
				score = (20 if is_hi == prefer_hi else -20) + (30 if is_forced == prefer_forced else -30)
				matches.append((score, index))
			if matches:
				xbmc.Player().setSubtitleStream(max(matches)[1])
				return True
			if attempt < 4: control.sleep(250)
		return False

	def _subtitle_score(self, item, playing_filename):
		filename = item.get('fileName') or ''
		release = item.get('release') or filename
		score = max(SequenceMatcher(None, playing_filename.lower(), filename.lower()).ratio(),
			SequenceMatcher(None, playing_filename.lower(), release.lower()).ratio()) * 100
		if item.get('moviehash_match'): score += 200
		if item.get('from_trusted'): score += 20
		score += min(float(item.get('ratings') or 0), 10) * 2
		score += min(int(item.get('download_count') or 0), 10000) / 1000.0
		prefer_hi = getSetting('subtitles.prefer.hearing_impaired') == 'true'
		prefer_forced = getSetting('subtitles.prefer.forced') == 'true'
		score += 20 if bool(item.get('hearing_impaired')) == prefer_hi else -20
		score += 30 if bool(item.get('foreign_parts_only')) == prefer_forced else -30
		return score

	def get(self, title, year, imdb, season, episode):
		try:
			quality = ['bluray', 'hdrip', 'brrip', 'bdrip', 'dvdrip', 'webrip', 'hdtv']
			langs = []
			langs.append(getSetting('subtitles.lang.1'))
			langs.append(getSetting('subtitles.lang.2'))

			try: subLang = xbmc.Player().getSubtitles()
			except: subLang = ''
			if self._language_code(subLang) == self._language_code(langs[0]):
				if getSetting('subtitles.notification') == 'true':
					if Player().isPlayback():
						control.sleep(1000)
						control.notification(message=getLS(32393) % subLang.upper(), time=5000)
				return log_utils.log(getLS(32393) % subLang.upper(), level=log_utils.LOGDEBUG)
			if self._select_embedded(langs[0]):
				if getSetting('subtitles.notification') == 'true':
					if Player().isPlayback():
						control.sleep(1000)
						control.notification(message=getLS(32394) % langs[0].upper(), time=5000)
				return log_utils.log(getLS(32394) % langs[0].upper(), level=log_utils.LOGDEBUG)
			if opensubs.Opensubs().auth():
				log_utils.log('OpenSubs Authorized.', level=log_utils.LOGDEBUG)
			else:
				return control.notification(message=getLS(40509), time=5000)
			if not (season is None or episode is None):
				#tv show

				result = opensubs.Opensubs().getSubs(title, imdb, year, season, episode)
				fmt = ['hdtv']

			else:
				#movie

				result = opensubs.Opensubs().getSubs(title, imdb, year, season, episode)
				if not result: return
				try: vidPath = xbmc.Player().getPlayingFile()
				except: vidPath = ''
				fmt = re.split(r'\.|\(|\)|\[|\]|\s|\-', vidPath)
				fmt = [i.lower() for i in fmt]
				fmt = [i for i in fmt if i in quality]
			filter = []
			try: vidPath = xbmc.Player().getPlayingFile()
			except: vidPath = ''
			pFileName = unquote(os.path.basename(vidPath))
			pFileName = os.path.splitext(pFileName)[0]
			matches = []
			if result:
				for j in result:
					if season:
							if seas_ep_filter(season, episode, j['fileName']):
								j['score'] = self._subtitle_score(j, pFileName)
								matches.append(j)
					else:
						j['score'] = self._subtitle_score(j, pFileName)
						matches.append(j)
			matches.sort(key = lambda i: i['score'], reverse = True)

			filter = matches
			if not filter: 
				if getSetting('subtitles.notification') == 'true':
					return control.notification(message=getLS(32395))
				else:
					return None
			
			try: lang = xbmc.convertLanguage(getSetting('subtitles.lang.1'), xbmc.ISO_639_1)
			except: lang = getSetting('subtitles.lang.1')
			filename = filter[0]['fileName']
			if self.debuglog:
				log_utils.log('downloaded subtitle=%s' % filename, level=log_utils.LOGDEBUG)
			try:
				downloadURL, downloadFileName = opensubs.Opensubs().downloadSubs(filter[0]['fileID'], filter[0]['fileName'])
			except:
				return log_utils.log('Error getting downloadurl or filename from opensubs.')
			if not control.existsPath(control.subtitlesPath): control.makeFile(control.subtitlesPath)
			download_path = control.subtitlesPath
			subtitle = download_path
			
			def find(pattern, path):
				result = []
				for root, dirs, files in os.walk(path):
					for name in files:
						if fnmatch.fnmatch(name, pattern):
							result.append(os.path.join(root, name))
				return result
			def download_opensubs(downloadURL, downloadFileName):
				log_utils.log('downloading srt file from opensubs.', level=log_utils.LOGDEBUG)
				reqqqq = Request(downloadURL, headers={'User-Agent' : "Magic Browser"})
				http_response = urlopen(reqqqq)
				response = http_response.read()
				response = response.decode('utf-8')
				srtFile = os.path.join(download_path, downloadFileName+'.srt')
				file = open(srtFile, 'w')
				file.write(response)
				file.close()
			from resources.lib.modules import tools
			tools.delete_all_subs()
			try:
				download_opensubs(downloadURL, downloadFileName)
			except:
				log_utils.error()
			subtitles = find('*.srt', subtitle)
			subtitle_matches = []
			if len(subtitles) > 1:
				if season:
					for count, i in enumerate(subtitles):
						sFileName = unquote(os.path.basename(i))
						sFileName = os.path.splitext(sFileName)[0]
						if seas_ep_filter(season, episode, sFileName.lower()):
							seq = SequenceMatcher(None, pFileName.lower(), sFileName.lower())
							subtitle_matches.append({'fullPath': subtitles[count], 'matchRatio': seq.ratio()})
				else:
					for count, i in enumerate(subtitles):
						sFileName = unquote(os.path.basename(i))
						sFileName = os.path.splitext(sFileName)[0]
						seq = SequenceMatcher(None, pFileName.lower(), sFileName.lower())
						subtitle_matches.append({'fullPath': subtitles[count], 'matchRatio': seq.ratio()})
				subtitle_matches.sort(key = lambda i: i['matchRatio'], reverse = True)
				subtitles = subtitle_matches[0]['fullPath']
			else:
				subtitles = subtitles[0]
			xbmc.sleep(1000)
			tempFileName = control.joinPath(download_path,'TemporarySubs.%s.srt' % lang)
			f = open(subtitles,"r")
			f1 = open(tempFileName,"w")
			for line in f.readlines():
				f1.write(line)
			f.close()
			f1.close()
			
		
			xbmc.Player().setSubtitles(tempFileName)
			if getSetting('subtitles.notification') == 'true':
				if Player().isPlayback():
					control.sleep(500)
					control.notification(title=filename, message=getLS(40506) % lang.upper())
		except: log_utils.error()

	def downloadForPlayNext(self,  title, year, imdb, season, episode, media_length):
		try:
			try:
				import re
			except: return log_utils.error()
			try: lang = xbmc.convertLanguage(getSetting('subtitles.lang.1'), xbmc.ISO_639_1)
			except: lang = getSetting('subtitles.lang.1')
			if not control.existsPath(control.subtitlesPath): control.makeFile(control.subtitlesPath)
			download_path = control.subtitlesPath
			try:
				tempFileName = control.joinPath(download_path,'TemporarySubs.%s.srt' % lang)
				if os.path.isfile(tempFileName):
					log_utils.log('downloaded subtitle file found. getting time from file.', level=log_utils.LOGDEBUG)
					xbmc.sleep(1000)
					times = []
					pattern = r'(\d{2}:\d{2}:\d{2},d{3}$)|(\d{2}:\d{2}:\d{2})'
					with control.openFile(tempFileName) as file:
						text = file.read()
						times = re.findall(pattern, text)
						times = times[len(times)-4][-1]
						file.close()
					if len(times) > 0:
						total_time = media_length
						h, m, s = str(times).split(':')
						totalSeconds =  int(h) * 3600 + int(m) * 60 + int(s)
						playnextTime = int(total_time) - int(totalSeconds)
					else:
						log_utils.log('subtitle time not found returning default', level=log_utils.LOGDEBUG)
						playnextTime = 'default'
					return playnextTime
			except:
				log_utils.error()
				return 'default'
			if getSetting('subtitles') == 'true':
				# Auto-download is enabled; get() handles the download and writes the temp file.
				# Temp file not found yet means get() is still running — don't download twice.
				return 'default'
			try:
				quality = ['bluray', 'hdrip', 'brrip', 'bdrip', 'dvdrip', 'webrip', 'hdtv']

				langs = []
				langs.append(getSetting('subtitles.lang.1'))
				langs.append(getSetting('subtitles.lang.2'))

				if opensubs.Opensubs().auth():
					pass
				else:
					log_utils.log('opensubs is not authorized but is set for playnext. please authorize open subs in addon. returning default', level=log_utils.LOGDEBUG)
					return 'default'
				if not (season is None or episode is None):

					result = opensubs.Opensubs().getSubs(title, imdb, year, season, episode)
					fmt = ['hdtv']
					if not result:
						log_utils.log('no results from opensubs for title: %s imdb: %s year: %s season: %s episode: %s returning default' % (title, imdb, year, season, episode), level=log_utils.LOGDEBUG)
						return 'default'
				else:
					#movie

					result = opensubs.Opensubs().getSubs(title, imdb, year, season, episode)
					if not result: return
					try: vidPath = xbmc.Player().getPlayingFile()
					except: vidPath = ''
					fmt = re.split(r'\.|\(|\)|\[|\]|\s|\-', vidPath)
					fmt = [i.lower() for i in fmt]
					fmt = [i for i in fmt if i in quality]
				filter = []
				try: vidPath = xbmc.Player().getPlayingFile()
				except: vidPath = ''
				pFileName = unquote(os.path.basename(vidPath))
				pFileName = os.path.splitext(pFileName)[0]
				matches = []
				if result:
					for j in result:
						if season:
								if seas_ep_filter(season, episode, j['fileName']):
									j['score'] = self._subtitle_score(j, pFileName)
									matches.append(j)
						else:
							j['score'] = self._subtitle_score(j, pFileName)
							matches.append(j)
				matches.sort(key = lambda i: i['score'], reverse = True)

				filter = matches
				if not filter: return None
				
				try: lang = xbmc.convertLanguage(getSetting('subtitles.lang.1'), xbmc.ISO_639_1)
				except: lang = getSetting('subtitles.lang.1')
				filename = filter[0]['fileName']
				if self.debuglog:
					log_utils.log('downloaded subtitle=%s' % filename, level=log_utils.LOGDEBUG)

				downloadURL, downloadFileName = opensubs.Opensubs().downloadSubs(filter[0]['fileID'], filter[0]['fileName'])
				subtitle = control.transPath(download_path)
				
				def find(pattern, path):
					result = []
					for root, dirs, files in os.walk(path):
						for name in files:
							if fnmatch.fnmatch(name, pattern):
								result.append(os.path.join(root, name))
					return result
				def download_opensubs(downloadURL, downloadFileName):
					log_utils.log('downloading srt file from opensubs.', level=log_utils.LOGDEBUG)
					reqqqq = Request(downloadURL, headers={'User-Agent' : "Magic Browser"})
					http_response = urlopen(reqqqq)
					response = http_response.read()
					response = response.decode('utf-8')
					log_utils.log('built http_response opensubs.', level=log_utils.LOGDEBUG)
					srtFile = os.path.join(download_path, downloadFileName+'.srt')
					file = open(srtFile, 'w')
					log_utils.log('opened file %s' % srtFile, level=log_utils.LOGDEBUG)
					file.write(response)
					log_utils.log('wrote to file.', level=log_utils.LOGDEBUG)
					file.close()
				from resources.lib.modules import tools
				tools.delete_all_subs()
				download_opensubs(downloadURL, downloadFileName)
				subtitles = find('*.srt', subtitle)
				subtitle_matches = []
				if len(subtitles) > 1:
					if season:
						for count, i in enumerate(subtitles):
							sFileName = unquote(os.path.basename(i))
							sFileName = os.path.splitext(sFileName)[0]
							if seas_ep_filter(season, episode, sFileName.lower()):
								seq = SequenceMatcher(None, pFileName.lower(), sFileName.lower())
								subtitle_matches.append({'fullPath': subtitles[count], 'matchRatio': seq.ratio()})
					else:
						for count, i in enumerate(subtitles):
							sFileName = unquote(os.path.basename(i))
							sFileName = os.path.splitext(sFileName)[0]
							seq = SequenceMatcher(None, pFileName.lower(), sFileName.lower())
							subtitle_matches.append({'fullPath': subtitles[count], 'matchRatio': seq.ratio()})
					subtitle_matches.sort(key = lambda i: i['matchRatio'], reverse = True)
					subtitles = subtitle_matches[0]['fullPath']
				else:
					subtitles = subtitles[0]
				xbmc.sleep(1000)
				tempFileName = control.joinPath(download_path,'TemporarySubs2.%s.srt' % lang)
				f = open(subtitles,"r")
				f1 = open(tempFileName,"a")
				for line in f.readlines():
					f1.write(line)
				f.close()
				f1.close()
				xbmc.sleep(1000)
				times = []
				pattern = r'(\d{2}:\d{2}:\d{2},d{3}$)|(\d{2}:\d{2}:\d{2})'
				with control.openFile(tempFileName) as file:
					text = file.read()
					times = re.findall(pattern, text)
					times = times[len(times)-4][-1]
					file.close()
				if len(times) > 0:
					total_time = media_length
					h, m, s = str(times).split(':')
					totalSeconds =  int(h) * 3600 + int(m) * 60 + int(s)
					playnextTime = int(total_time) - int(totalSeconds)
				else:
					playnextTime = 'default'
				log_utils.log('Playnext Returning %s for time.' % playnextTime, level=log_utils.LOGDEBUG)
				return playnextTime
			except:
				log_utils.error()
				return 'default'
		except:
			log_utils.error()
			return 'default'


class Bookmarks:
	def __init__(self):
		self.debuglog = control.setting('debug.enabled') == 'true' and control.setting('debug.level') == '1'
		self.traktCredentials = trakt.getTraktCredentialsInfo()
		self.simklCredentials = simkl.getSimKLCredentialsInfo()
		self.mdblistCredentials = mdblist.getMDBListCredentialsInfo()
		self.customCredentials = customtrakt.getCustomCredentialsInfo()
		self.floppyCredentials = floppy.getFloppyCredentialsInfo()
		self.scrobCredentials = scrob.getScrobCredentialsInfo()
		self.punchplayCredentials = punchplay.getPunchPlayCredentialsInfo()
		self.custom_rewatch = False
	def get(self, name, imdb=None, tmdb=None, tvdb=None, season=None, episode=None, year='0', runtime=None, ck=False, kodi_resume=None):
		markwatched_percentage = int(getSetting('markwatched.percent')) or 85
		offset = '0'
		scrobbble = 'Local Bookmark'
		scrobbble = 'Local Bookmark'
		if getSetting('bookmarks') != 'true': return offset
		resume_source = getSetting('scrobble.source')
		if self.traktCredentials and resume_source == '1':
			scrobbble = 'Trakt Resume Point'
			scrobbble = 'Trakt Resume Point'
			try:
				if not runtime or runtime == 'None': return offset # TMDB sometimes return None as string. duration pulled from kodi library if missing from meta
				progress = float(fetch_bookmarks(imdb, tmdb, tvdb, season, episode))
				offset = (progress / 100) * runtime # runtime vs. media_length can differ resulting in 10-30sec difference using Trakt scrobble, meta providers report runtime in full minutes
				display_offset = offset * 60
				seekable = (2 <= progress <= int(markwatched_percentage))
				if not seekable: return '0'
			except:
				log_utils.error()
				return '0'
		elif self.simklCredentials and resume_source == '2':
			scrobbble = 'Simkl Resume Point'
			scrobbble = 'Simkl Resume Point'
			try:
				if not runtime or runtime == 'None': return offset
				progress = float(simklsync.fetch_bookmarks(imdb, tmdb, tvdb, season, episode))
				offset = (progress / 100) * runtime
				display_offset = offset * 60
				seekable = (2 <= progress <= int(markwatched_percentage))
				if not seekable: return '0'
			except:
				log_utils.error()
				return '0'
		elif self.mdblistCredentials and resume_source == '3':
			scrobbble = 'MDBList Resume Point'
			scrobbble = 'MDBList Resume Point'
			try:
				if not runtime or runtime == 'None': return offset
				from resources.lib.database import mdbsync
				progress = float(mdbsync.fetch_bookmarks(imdb, tmdb, tvdb, season, episode))
				offset = (progress / 100) * runtime
				display_offset = offset * 60
				seekable = (2 <= progress <= int(markwatched_percentage))
				if not seekable: return '0'
			except:
				log_utils.error()
				return '0'
		elif self.customCredentials and resume_source == '4':
			scrobbble = '%s Resume Point' % customtrakt.getCustomServiceName()
			scrobbble = '%s Resume Point' % customtrakt.getCustomServiceName()
			try:
				from resources.lib.database import customtraktsync
				if episode and customtraktsync.is_watched_episode(imdb, tmdb, tvdb, season, episode):
					# Clear progress from the completed watch and start a distinct rewatch cycle.
					customtraktsync.delete_bookmark(imdb, tvdb or '', season, episode)
					self.custom_rewatch = True
					return '0'
				if not runtime or runtime == 'None': return offset
				progress = float(customtraktsync.fetch_bookmarks(imdb, tmdb, tvdb, season, episode))
				offset = (progress / 100) * runtime
				display_offset = offset * 60
				# A custom-server rewatch may be stopped very early. Any positive progress
				# belongs to the new watch cycle and must remain resumable.
				seekable = (0 < progress < int(markwatched_percentage))
				if not seekable: return '0'
			except:
				log_utils.error()
				return '0'
		elif self.floppyCredentials and resume_source == '5':
			scrobbble = 'Floppy Resume Point'
			scrobbble = 'Floppy Resume Point'
			try:
				if not runtime or runtime == 'None': return offset
				from resources.lib.database import floppysync
				progress = float(floppysync.fetch_bookmarks(imdb, tmdb, tvdb, season, episode))
				offset = (progress / 100) * runtime
				display_offset = offset * 60
				seekable = (2 <= progress <= int(markwatched_percentage))
				if not seekable: return '0'
			except:
				log_utils.error()
				return '0'
		elif self.scrobCredentials and resume_source == '6':
			scrobbble = 'Scrob Resume Point'
			try:
				if not runtime or runtime == 'None': return offset
				from resources.lib.database import scrobsync
				progress = float(scrobsync.fetch_bookmarks(imdb, tmdb, tvdb, season, episode))
				if progress <= 0:
					progress = float(scrob.get_resume_percent(tmdb, season=season, episode=episode) or 0)
				offset = (progress / 100) * runtime
				display_offset = offset * 60
				seekable = (2 <= progress <= int(markwatched_percentage))
				if not seekable: return '0'
			except:
				log_utils.error()
				return '0'
		elif self.punchplayCredentials and resume_source == '7':
			scrobbble = 'PunchPlay Resume Point'
			try:
				item = punchplay.get_resume_item(tmdb, season, episode)
				if not item: return '0'
				progress = item['progress_percent'] * 100
				display_offset = item['position_seconds']
				offset = display_offset / 60
				seekable = (2 <= progress <= int(markwatched_percentage))
				if not seekable: return '0'
			except:
				log_utils.error()
				return '0'
		else:
			try:
				dbcon = database.connect(control.bookmarksFile)
				dbcur = dbcon.cursor()
				dbcur.execute('''CREATE TABLE IF NOT EXISTS bookmark (idFile TEXT, timeInSeconds TEXT, Name TEXT, year TEXT, UNIQUE(idFile));''')
				if not year or year == 'None': return offset
				years = [str(year), str(int(year)+1), str(int(year)-1)]
				_ph = ','.join('?' * len(years))
				match = dbcur.execute('SELECT * FROM bookmark WHERE Name=? AND year IN (%s)' % _ph, [name] + years).fetchone() # helps fix random cases where trakt and imdb, or tvdb, differ by a year for eps
			except:
				log_utils.error()
				return offset
			finally:
				dbcur.close() ; dbcon.close()
			if not match: return offset
			#offset = str(match[1]) 
			#changed to correct issue with resumes.
			offset = float(match[1])
			display_offset = offset
		if ck: return offset
		# A native Kodi playback action is authoritative. resume:true keeps the
		# provider offset; resume:false explicitly starts from the beginning.
		if kodi_resume is True: return offset
		if kodi_resume is False: return '0'
		minutes, seconds = divmod(display_offset, 60)
		hours, minutes = divmod(minutes, 60)
		label = '%02d:%02d:%02d' % (hours, minutes, seconds)
		label = getLS(32502) % label
		if getSetting('bookmarks.auto') == 'false':
			select = control.yesnocustomDialog(label, scrobbble, '', str(name), 'Cancel Playback', getLS(32503), getLS(32501))
			if select == 1: offset = '0'
			elif select == -1 or select == 2: offset = '-1'
		return offset

	def reset(self, current_time, media_length, name, year='0'):
		try:
			markwatched_percentage = int(getSetting('markwatched.percent')) or 85
			clear_local_bookmarks() # clear all umbrella bookmarks from kodi database
			if getSetting('bookmarks') != 'true' or media_length == 0 or current_time == 0: return
			timeInSeconds = str(current_time)
			seekable = (int(current_time) > 180 and (current_time / media_length) < (abs(float(markwatched_percentage) / 100)))
			idFile = md5()
			try: [idFile.update(str(i)) for i in name]
			except: [idFile.update(str(i).encode('utf-8')) for i in name]
			try: [idFile.update(str(i)) for i in year]
			except: [idFile.update(str(i).encode('utf-8')) for i in year]
			idFile = str(idFile.hexdigest())
			control.makeFile(control.dataPath)
			dbcon = database.connect(control.bookmarksFile)
			dbcur = dbcon.cursor()
			dbcur.execute('''CREATE TABLE IF NOT EXISTS bookmark (idFile TEXT, timeInSeconds TEXT, Name TEXT, year TEXT, UNIQUE(idFile));''')
			years = [str(year), str(int(year) + 1), str(int(year) - 1)]
			_ph = ','.join('?' * len(years))
			dbcur.execute('DELETE FROM bookmark WHERE Name=? AND year IN (%s)' % _ph, [name] + years) #helps fix random cases where trakt and imdb, or tvdb, differ by a year for eps
			if seekable:
				dbcur.execute('''INSERT INTO bookmark Values (?, ?, ?, ?)''', (idFile, timeInSeconds, name, year))
				minutes, seconds = divmod(float(timeInSeconds), 60)
				hours, minutes = divmod(minutes, 60)
				label = ('%02d:%02d:%02d' % (hours, minutes, seconds))
				message = getLS(32660)
				if getSetting('localnotify') == 'true':
					control.notification(title=name, message=message + '(' + label + ')')
			dbcur.connection.commit()
			try: dbcur.close ; dbcon.close()
			except: pass
		except:
			log_utils.error()

	def set_scrobble(self, current_time, media_length, media_type, imdb='', tmdb='', tvdb='', season='', episode='', service='trakt', title='', tvshowtitle='', year='0', already_watched=False):
		# Ensure season and episode are not None
		season = season if season is not None else ''
		episode = episode if episode is not None else ''
		try:
			markwatched_percentage = int(getSetting('markwatched.percent')) or 85
			# Closing the remote session must also work before Kodi reports a duration.
			percent = float(current_time / media_length) * 100 if media_length > 0 else 0
			seekable = (int(current_time) > 180 and (percent < int(markwatched_percentage)))
			# Always close active sessions, even below the local three-minute bookmark threshold.
			# Skip scrobble API call if item was already marked watched during playback (avoids duplicate submission)
			skip_scrobble = already_watched and percent >= int(markwatched_percentage)
			if service == 'simkl':
				if not skip_scrobble:
					simkl.scrobbleMovie(title, year, imdb, tmdb, percent) if media_type == 'movie' else simkl.scrobbleEpisode(tvshowtitle or title, year, imdb, tmdb, tvdb, season, episode, percent)
				if percent >= int(markwatched_percentage):
					# Capture the local ID before the remote delete. Completion remains
					# authoritative when Simkl already removed the playback entry.
					resume_info = simklsync.fetch_bookmarks(imdb, tmdb, tvdb, season, episode, ret_type='resume_info')
					simkl.scrobbleReset(imdb, tmdb, tvdb, season, episode, refresh=False)
					if resume_info != '0': simklsync.delete_bookmark(resume_info[1])
			elif service == 'mdblist':
				# Do not create a new pause bookmark immediately before clearing a
				# completed item. If the subsequent clear is delayed or fails, that
				# final pause point is synced back and leaves the episode in progress.
				if not skip_scrobble and percent < markwatched_percentage:
					mdblist.scrobbleMovie(title, year, imdb, tmdb, percent) if media_type == 'movie' else mdblist.scrobbleEpisode(tvshowtitle or title, year, imdb, tmdb, tvdb, season, episode, percent)
				if percent >= int(markwatched_percentage): mdblist.scrobbleReset(imdb, tmdb, tvdb, season, episode, refresh=False, already_watched=skip_scrobble)
			elif service == 'custom':
				if not skip_scrobble:
					customtrakt.scrobbleMovie(imdb, tmdb, percent) if media_type == 'movie' else customtrakt.scrobbleEpisode(imdb, tmdb, tvdb, season, episode, percent)
				if percent >= int(markwatched_percentage):
					customtrakt.scrobbleReset(imdb, tmdb, tvdb, season, episode, refresh=False)
			elif service == 'floppy':
				completed = percent >= int(markwatched_percentage)
				if getSetting('debug.level') == '1':
					log_utils.log('FLOPPY: set_scrobble stop gate — percent=%.2f current_time=%s media_length=%s seekable=%s completed=%s skip_scrobble=%s' % (percent, current_time, media_length, seekable, completed, skip_scrobble), level=log_utils.LOGDEBUG)
				floppy.scrobbleStopMovie(imdb, tmdb, percent, completed=completed, current_time=current_time, total_time=media_length, already_watched=skip_scrobble) if media_type == 'movie' else floppy.scrobbleStopEpisode(imdb, tmdb, tvdb, season, episode, percent, completed=completed, current_time=current_time, total_time=media_length, already_watched=skip_scrobble)
				if percent >= int(markwatched_percentage):
					floppy.scrobbleReset(imdb, tmdb, tvdb, season, episode, refresh=False, remote=False)
			elif service == 'scrob':
				completed = percent >= int(markwatched_percentage)
				if getSetting('debug.level') == '1':
					log_utils.log('SCROB: set_scrobble stop gate — percent=%.2f current_time=%s media_length=%s seekable=%s completed=%s skip_scrobble=%s' % (percent, current_time, media_length, seekable, completed, skip_scrobble), level=log_utils.LOGDEBUG)
				scrob.scrobbleStopMovie(imdb, tmdb, percent, completed=completed, current_time=current_time, total_time=media_length, already_watched=skip_scrobble) if media_type == 'movie' else scrob.scrobbleStopEpisode(imdb, tmdb, tvdb, season, episode, percent, completed=completed, current_time=current_time, total_time=media_length, already_watched=skip_scrobble)
				if percent >= int(markwatched_percentage):
					scrob.scrobbleReset(imdb, tmdb, tvdb, season, episode, refresh=False, remote=False)
			elif service == 'punchplay':
				completed = percent >= int(markwatched_percentage)
				if media_type == 'movie':
					punchplay.scrobbleStopMovie(imdb, tmdb, percent, completed=completed, current_time=current_time, total_time=media_length)
				else:
					punchplay.scrobbleStopEpisode(imdb, tmdb, tvdb, season, episode, percent, completed=completed, current_time=current_time, total_time=media_length)
			else:
				if not skip_scrobble:
					trakt.scrobbleMovie(imdb, tmdb, percent) if media_type == 'movie' else trakt.scrobbleEpisode(imdb, tmdb, tvdb, season, episode, percent)
				if percent >= int(markwatched_percentage):
					trakt.scrobbleReset(imdb, tmdb, tvdb, season, episode, refresh=False)
					# Completion is authoritative even if Trakt already removed the remote
					# playback entry and DELETE therefore did not return 204. Never retain
					# a stale local resume point for a completed item.
					if media_type == 'movie':
						item = {'type': 'movie', 'movie': {'ids': {'imdb': imdb}}}
					else:
						item = {'type': 'episode', 'episode': {'season': season, 'number': episode},
								'show': {'ids': {'imdb': imdb, 'tvdb': tvdb}}}
					from resources.lib.database import traktsync as _traktsync
					_traktsync.delete_bookmark([item])
		except:
			log_utils.error()

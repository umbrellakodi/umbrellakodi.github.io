# -*- coding: utf-8 -*-
"""
	Umbrella Add-on
"""
# Local cache DB for the Floppy service (dannyvfilms/Floppy fork).
# Floppy's data model is a single 'status' field per tracked item
# (Planning/In progress/Paused/Completed/Dropped) rather than Trakt's
# separate watchlist/collection/history, so this mirrors simklsync.py's
# 5-bucket status-list layout more than customtraktsync.py's shape,
# while reusing customtraktsync.py's cache/bookmark table patterns.

import re
import hashlib
from ast import literal_eval
from sqlite3 import dbapi2 as db
from datetime import datetime
from time import time
from resources.lib.modules.control import existsPath, dataPath, makeFile, floppySyncFile
from resources.lib.modules import cleandate

def get_connection(setRowFactory=False):
	if not existsPath(dataPath): makeFile(dataPath)
	dbcon = db.connect(floppySyncFile, timeout=60)
	dbcon.execute('''PRAGMA page_size = 32768''')
	dbcon.execute('''PRAGMA journal_mode = DELETE''')
	dbcon.execute('''PRAGMA synchronous = NORMAL''')
	dbcon.execute('''PRAGMA temp_store = memory''')
	dbcon.execute('''PRAGMA mmap_size = 30000000000''')
	if setRowFactory: dbcon.row_factory = _dict_factory
	return dbcon

def get_connection_cursor(dbcon):
	return dbcon.cursor()

def _dict_factory(cursor, row):
	d = {}
	for idx, col in enumerate(cursor.description): d[col[0]] = row[idx]
	return d


#Status-bucket tables (Watchlist/Watching/On Hold/Completed/Dropped/Collection) — generic list-cache shape

def fetch_status_list(table):
	result = []
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name=?;''', (table,)).fetchone()
		if not ck_table:
			dbcur.execute('''CREATE TABLE IF NOT EXISTS %s (title TEXT, year TEXT, tmdb TEXT, item_id TEXT, image TEXT, score TEXT, listed_at TEXT, UNIQUE(tmdb));''' % table)
			dbcur.connection.commit()
			return result
		match = dbcur.execute('''SELECT * FROM %s WHERE NOT title=""''' % table).fetchall()
		# imdb/tvdb/premiered/rating/votes aren't available from Floppy (tmdb-native,
		# unified status model) but are included as blanks for compatibility with the
		# generic worker()/movieDirectory() pipeline shared with the other providers.
		result = [{'title': i[0], 'year': i[1], 'premiered': '', 'imdb': '', 'tmdb': i[2], 'tvdb': '', 'item_id': i[3], 'image': i[4], 'rating': '', 'votes': '', 'score': i[5], 'added': i[6]} for i in match]
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass
	return result

def insert_status_list(items, table, new_sync=True):
	# items: list of Floppy MediaSerializer objects, i.e.
	# {'id': <item pk>, 'item': {'media_id','source','media_type','title','image',...}, 'status': int, 'score': float, ...}
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		dbcur.execute('''CREATE TABLE IF NOT EXISTS %s (title TEXT, year TEXT, tmdb TEXT, item_id TEXT, image TEXT, score TEXT, listed_at TEXT, UNIQUE(tmdb));''' % table)
		dbcur.execute('''CREATE TABLE IF NOT EXISTS service (setting TEXT, value TEXT, UNIQUE(setting));''')
		if new_sync:
			dbcur.execute('''DELETE FROM %s''' % table)
		for i in items:
			if not i: continue
			item = i.get('item') or {}
			tmdb = str(item.get('media_id') or '')
			if not tmdb: continue
			title = item.get('title', '')
			image = item.get('image', '') or ''
			score = str(i.get('score', '') or '')
			item_id = str(i.get('id', '') or '')
			listed_at = i.get('created_at', '') or ''
			dbcur.execute('''INSERT OR REPLACE INTO %s Values (?, ?, ?, ?, ?, ?, ?)''' % table, (title, '', tmdb, item_id, image, score, listed_at))
		timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z")
		dbcur.execute('''INSERT OR REPLACE INTO service Values (?, ?)''', ('last_%s_sync_at' % table, timestamp))
		dbcur.connection.commit()
		return True
	except:
		try: dbcon.rollback()
		except: pass
		from resources.lib.modules import log_utils
		log_utils.error()
		return False
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass

def delete_floppy_tables(tables):
	# Delete and vacuum the specified Floppy tables, and reset their service timestamps.
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		for table in tables:
			try:
				ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name=?;''', (table,)).fetchone()
				if ck_table:
					dbcur.execute('DELETE FROM %s' % table)
			except:
				from resources.lib.modules import log_utils
				log_utils.error()
		dbcur.execute('''CREATE TABLE IF NOT EXISTS service (setting TEXT, value TEXT, UNIQUE(setting));''')
		epoch = '1970-01-01T00:00:00.000Z'
		for key in ('last_history_at', 'last_watched_movies_at', 'last_watched_episodes_at'):
			dbcur.execute('''INSERT OR REPLACE INTO service Values (?, ?)''', (key, epoch))
		_bump_revision(dbcur, 'history')
		_bump_revision(dbcur, 'bookmarks')
		dbcur.connection.commit()
		dbcur.execute('''VACUUM''')
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass

def last_sync(type):
	last_sync_at = 0
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='service';''').fetchone()
		if ck_table:
			match = dbcur.execute('''SELECT * FROM service WHERE setting=?;''', (type,)).fetchone()
			if match: last_sync_at = int(cleandate.iso_2_utc(match[1]))
			else: dbcur.execute('''INSERT OR REPLACE INTO service Values (?, ?)''', (type, '1970-01-01T20:00:00.000Z'))
		else: dbcur.execute('''CREATE TABLE IF NOT EXISTS service (setting TEXT, value TEXT, UNIQUE(setting));''')
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass
	return last_sync_at

def update_last_watched_at(key='last_history_at'):
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		dbcur.execute('''CREATE TABLE IF NOT EXISTS service (setting TEXT, value TEXT, UNIQUE(setting));''')
		timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z")
		dbcur.execute('''INSERT OR REPLACE INTO service Values (?, ?)''', (key, timestamp))
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass


#Watched movies / episodes tables (aggregated client-side, mirrors customtraktsync.py's shape).
#Floppy is TMDB-native so imdb/tvdb columns are kept for cross-lookup convenience but tmdb is authoritative.

def _ensure_watched_tables(dbcur):
	dbcur.execute('''CREATE TABLE IF NOT EXISTS floppy_watched_movies (imdb TEXT, tmdb TEXT, title TEXT, year TEXT, last_watched_at TEXT, UNIQUE(tmdb));''')
	dbcur.execute('''CREATE TABLE IF NOT EXISTS floppy_watched_episodes (show_imdb TEXT, show_tmdb TEXT, show_tvdb TEXT, season INTEGER, episode INTEGER, last_watched_at TEXT, UNIQUE(show_tmdb, season, episode));''')
	dbcur.execute('''CREATE TABLE IF NOT EXISTS service (setting TEXT, value TEXT, UNIQUE(setting));''')

def upsert_watched_movie(imdb='', tmdb='', title='', year='', last_watched_at=''):
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		_ensure_watched_tables(dbcur)
		dbcur.execute('''INSERT OR REPLACE INTO floppy_watched_movies Values (?, ?, ?, ?, ?)''', (imdb, str(tmdb), title, str(year), last_watched_at))
		_bump_revision(dbcur, 'history')
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass

def upsert_watched_episode(show_imdb='', show_tmdb='', show_tvdb='', season=0, episode=0, last_watched_at=''):
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		_ensure_watched_tables(dbcur)
		dbcur.execute('''INSERT OR REPLACE INTO floppy_watched_episodes Values (?, ?, ?, ?, ?, ?)''', (show_imdb, str(show_tmdb), str(show_tvdb), int(season), int(episode), last_watched_at))
		_bump_revision(dbcur, 'history')
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass

def delete_watched_movie(tmdb):
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		_ensure_watched_tables(dbcur)
		dbcur.execute('''DELETE FROM floppy_watched_movies WHERE tmdb=?''', (str(tmdb),))
		_bump_revision(dbcur, 'history')
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass

def delete_watched_episode(show_tmdb, season, episode):
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		_ensure_watched_tables(dbcur)
		dbcur.execute('''DELETE FROM floppy_watched_episodes WHERE show_tmdb=? AND season=? AND episode=?''', (str(show_tmdb), int(season), int(episode)))
		_bump_revision(dbcur, 'history')
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass

def get_watched_movies():
	result = []
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		_ensure_watched_tables(dbcur)
		# getMovieOverlay() (playcount.py) matches this list against a real imdb id, not
		# tmdb, so this must select imdb — even though tmdb is the table's unique key.
		rows = dbcur.execute("SELECT imdb FROM floppy_watched_movies WHERE imdb != ''").fetchall()
		result = [r[0] for r in rows]
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass
	return result

def get_watched_movies_full():
	# Full rows (imdb, tmdb, title, year, last_watched_at) for the dedicated Watched
	# list — get_watched_movies() above only selects imdb for the indicator-matching
	# path and can't be reused for a real history-sorted list.
	result = []
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		_ensure_watched_tables(dbcur)
		rows = dbcur.execute('''SELECT imdb, tmdb, title, year, last_watched_at FROM floppy_watched_movies''').fetchall()
		result = [(r[0], r[1], r[2], r[3], r[4]) for r in rows]
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass
	return result

def get_watched_episodes():
	result = []
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		_ensure_watched_tables(dbcur)
		rows = dbcur.execute('''SELECT show_imdb, show_tmdb, show_tvdb, season, episode FROM floppy_watched_episodes''').fetchall()
		result = [(r[0], r[1], r[2], r[3], r[4]) for r in rows]
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass
	return result

def get_watched_shows():
	result = []
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		_ensure_watched_tables(dbcur)
		rows = dbcur.execute('''SELECT show_imdb, show_tmdb, show_tvdb, MAX(last_watched_at) AS last_watched_at
			FROM floppy_watched_episodes GROUP BY show_tmdb ORDER BY last_watched_at DESC''').fetchall()
		result = [(r[0], r[1], r[2], r[3]) for r in rows]
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass
	return result


#Cache table (indicator/progress cache — same key/value/date shape used by mdbsync.py/customtraktsync.py)

def _hash_function(function_instance, args=()):
	name = re.sub(r'.+\smethod\s|.+function\s|\sat\s.+|\sof\s.+', '', repr(function_instance))
	md5 = hashlib.md5(repr(args).encode('utf-8')).hexdigest()
	return name + md5

def cache_get(key):
	try:
		dbcon = get_connection(setRowFactory=True)
		dbcur = get_connection_cursor(dbcon)
		ck = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='watched';''').fetchone()
		if not ck: return None
		return dbcur.execute('''SELECT * FROM watched WHERE key=?''', (key,)).fetchone()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return None
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass

def cache_insert(key, value):
	try:
		dbcon = get_connection(setRowFactory=True)
		dbcur = get_connection_cursor(dbcon)
		now = int(time())
		dbcur.execute('''CREATE TABLE IF NOT EXISTS watched (key TEXT, value TEXT, date INTEGER, UNIQUE(key));''')
		dbcur.execute('''INSERT OR REPLACE INTO watched Values (?, ?, ?)''', (key, value, now))
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass

def cache_delete(key):
	try:
		dbcon = get_connection(setRowFactory=True)
		dbcur = get_connection_cursor(dbcon)
		ck = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='watched';''').fetchone()
		if ck:
			dbcur.execute('''DELETE FROM watched WHERE key=?''', (key,))
			dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass

def clear_cache():
	# Truncates the whole cache table without touching the service-timestamp table —
	# delete_floppy_tables() also resets last_history_at/etc. to epoch as a side effect,
	# which would fight a just-written update_last_watched_at() call if reused for this.
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='watched';''').fetchone()
		if ck:
			dbcur.execute('''DELETE FROM watched''')
			dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass

def cache_existing(function, *args):
	try:
		result = cache_get(_hash_function(function, args))
		if result: return literal_eval(result['value'])
		return None
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return None

def get(function, duration, *args):
	try:
		key = _hash_function(function, args)
		cache_result = cache_get(key)
		if cache_result and duration != 0:
			if int(time()) - cache_result['date'] < (duration * 60):
				return literal_eval(cache_result['value'])
		fresh_result = repr(function(*args))
		if fresh_result and fresh_result not in ('None', "''", '[]', '{}'):
			cache_insert(key, fresh_result)
		return literal_eval(fresh_result) if fresh_result else None
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return None

def timeout(function, *args, returnNone=False):
	try:
		key = _hash_function(function, args)
		cache_result = cache_get(key)
		if cache_result: return cache_result['date']
		if returnNone: return None
		return 0
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return 0


#Bookmarks table (local resume points — Floppy's confirmed API has no queryable
#server-side "in progress playback" list, only start/pause/stop scrobble events, so
#this is populated purely from local scrobbleMovie/scrobbleEpisode calls).

def _ensure_bookmarks_table(dbcur):
	dbcur.execute('''CREATE TABLE IF NOT EXISTS bookmarks (tvshowtitle TEXT, title TEXT, resume_id TEXT, imdb TEXT, tmdb TEXT, tvdb TEXT, season TEXT, episode TEXT, genre TEXT, mpaa TEXT, studio TEXT, duration TEXT, percent_played TEXT, paused_at TEXT, UNIQUE(imdb, tmdb, tvdb, season, episode));''')
	dbcur.execute('''CREATE TABLE IF NOT EXISTS service (setting TEXT, value TEXT, UNIQUE(setting));''')

def upsert_bookmark(tvshowtitle='', title='', resume_id='', imdb='', tmdb='', tvdb='', season='', episode='', genre='', mpaa='', studio='', duration='', percent_played='', paused_at=''):
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		_ensure_bookmarks_table(dbcur)
		if not resume_id:
			import hashlib as _hl
			resume_id = _hl.md5(repr((imdb, tmdb, tvdb, season, episode)).encode('utf-8')).hexdigest()
		dbcur.execute('''INSERT OR REPLACE INTO bookmarks Values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
			(tvshowtitle, title, resume_id, imdb, tmdb, tvdb, season, episode, genre, mpaa, studio, duration, percent_played, paused_at))
		timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z")
		dbcur.execute('''INSERT OR REPLACE INTO service Values (?, ?)''', ('last_paused_at', timestamp))
		_bump_revision(dbcur, 'bookmarks')
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass

def fetch_bookmarks(imdb, tmdb='', tvdb='', season=None, episode=None, ret_all=None, ret_type='movies'):
	progress = '0'
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		_ensure_bookmarks_table(dbcur)
		dbcur.connection.commit()
		if ret_all:
			if ret_type == 'movies':
				match = dbcur.execute('''SELECT * FROM bookmarks WHERE (tvshowtitle='')''').fetchall()
				progress = [{'title': i[1], 'resume_id': i[2], 'imdb': i[3], 'tmdb': i[4], 'duration': int(i[11]) if i[11] else 0, 'progress': i[12], 'paused_at': i[13]} for i in match]
			else:
				match = dbcur.execute('''SELECT * FROM bookmarks WHERE NOT (tvshowtitle='')''').fetchall()
				progress = [{'tvshowtitle': i[0], 'title': i[1], 'resume_id': i[2], 'imdb': i[3], 'tmdb': i[4], 'tvdb': i[5], 'season': int(i[6]) if i[6] else 0, 'episode': int(i[7]) if i[7] else 0,
								'genre': i[8], 'mpaa': i[9], 'studio': i[10], 'duration': int(i[11]) if i[11] else 0, 'progress': i[12], 'paused_at': i[13]} for i in match]
		else:
			if not episode:
				try:
					match = dbcur.execute('''SELECT * FROM bookmarks WHERE (tmdb=? AND NOT tmdb='')''', (tmdb,)).fetchone()
					if ret_type == 'resume_info': progress = (match[1], match[2])
					else: progress = match[12]
				except: pass
			else:
				try:
					match = dbcur.execute('''SELECT * FROM bookmarks WHERE (tmdb=? AND season=? AND episode=? AND NOT tmdb='')''', (tmdb, str(season), str(episode))).fetchone()
					if ret_type == 'resume_info': progress = (match[0], match[2])
					else: progress = match[12]
				except: pass
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass
	return progress

def delete_bookmark(imdb, tvdb='', tmdb='', season='', episode=''):
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		_ensure_bookmarks_table(dbcur)
		dbcur.execute('''DELETE FROM bookmarks WHERE (tmdb=? AND season=? AND episode=?)''', (tmdb, str(season) if season else '', str(episode) if episode else ''))
		timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z")
		dbcur.execute('''INSERT OR REPLACE INTO service Values (?, ?)''', ('last_paused_at', timestamp))
		_bump_revision(dbcur, 'bookmarks')
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass

def clear_bookmarks():
	# Dedicated to just the bookmarks table — delete_floppy_tables() also resets
	# last_history_at as a side effect, which is unrelated here and would wrongly make
	# the watched-history sync think it needs a full resync.
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		_ensure_bookmarks_table(dbcur)
		dbcur.execute('''DELETE FROM bookmarks''')
		_bump_revision(dbcur, 'bookmarks')
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except: pass
		try: dbcon.close()
		except: pass


def store_watched_history(movies, episodes, replace=True, expected_revision=None):
	"""Commit a complete history fetch together; roll back failed replacements."""
	connection = None
	try:
		connection = get_connection()
		connection.execute('PRAGMA journal_mode = DELETE')
		connection.execute('PRAGMA synchronous = NORMAL')
		cursor = connection.cursor()
		_ensure_watched_tables(cursor)
		connection.execute('BEGIN IMMEDIATE')
		if expected_revision is not None and _read_revision(cursor, 'history') != expected_revision:
			connection.rollback()
			return False
		_reconcile_rows(cursor, 'floppy_watched_movies', movies, (1,), replace)
		_reconcile_rows(cursor, 'floppy_watched_episodes', episodes, (1, 3, 4), replace)
		_bump_revision(cursor, 'history')
		cursor.execute('CREATE TABLE IF NOT EXISTS service (setting TEXT, value TEXT, UNIQUE(setting))')
		cursor.execute('INSERT OR REPLACE INTO service VALUES (?, ?)',
			('last_history_at', datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.000Z')))
		connection.commit()
		return True
	except:
		if connection is not None: connection.rollback()
		from resources.lib.modules import log_utils
		log_utils.error()
		return False
	finally:
		if connection is not None: connection.close()


def acquire_sync_lock():
	"""Serialize service and plugin history rebuilds across Kodi interpreters."""
	if not existsPath(dataPath): makeFile(dataPath)
	connection = db.connect(floppySyncFile + '.sync-lock', timeout=0)
	try:
		connection.execute('BEGIN IMMEDIATE')
		return connection
	except db.OperationalError:
		connection.close()
		return None


def _read_revision(cursor, resource):
	cursor.execute('CREATE TABLE IF NOT EXISTS service (setting TEXT, value TEXT, UNIQUE(setting))')
	row = cursor.execute('SELECT value FROM service WHERE setting=?', ('revision_' + resource,)).fetchone()
	return int(row[0]) if row else 0


def _bump_revision(cursor, resource):
	value = _read_revision(cursor, resource) + 1
	cursor.execute('INSERT OR REPLACE INTO service VALUES (?, ?)', ('revision_' + resource, str(value)))


def get_revision(resource):
	connection = get_connection()
	try:
		return _read_revision(connection.cursor(), resource)
	finally:
		connection.close()


def _reconcile_rows(cursor, table, rows, key_columns, replace=True):
	"""Apply a snapshot's differences without clearing or rewriting unchanged rows."""
	old = {tuple(row[i] for i in key_columns): row for row in cursor.execute('SELECT * FROM ' + table)}
	new = {tuple(row[i] for i in key_columns): tuple(row) for row in rows}
	columns = [row[1] for row in cursor.execute('PRAGMA table_info(' + table + ')')]
	if replace:
		removed = [key for key in old if key not in new]
		where = ' AND '.join(columns[i] + '=?' for i in key_columns)
		cursor.executemany('DELETE FROM ' + table + ' WHERE ' + where, removed)
	changed = [row for key, row in new.items() if old.get(key) != row]
	if changed:
		cursor.executemany('INSERT OR REPLACE INTO ' + table + ' VALUES (' + ','.join('?' for _ in columns) + ')', changed)


def store_status_lists(snapshots):
	connection = get_connection()
	try:
		cursor = connection.cursor()
		connection.execute('BEGIN IMMEDIATE')
		for table, items in snapshots.items():
			if table not in ('movies_plantowatch', 'shows_plantowatch', 'movies_watching', 'shows_watching',
				'movies_hold', 'shows_hold', 'movies_completed', 'shows_completed', 'movies_dropped',
				'shows_dropped', 'movies_collection', 'shows_collection'): raise ValueError('Invalid status table')
			cursor.execute('CREATE TABLE IF NOT EXISTS ' + table + ' (title TEXT, year TEXT, tmdb TEXT, item_id TEXT, image TEXT, score TEXT, listed_at TEXT, UNIQUE(tmdb))')
			rows = []
			for entry in items:
				item = entry.get('item') or {}
				if item.get('source') not in (None, '', 'tmdb'): continue
				tmdb = str(item.get('media_id') or '')
				if not tmdb: raise ValueError('Missing TMDB identity')
				rows.append((item.get('title') or '', '', tmdb, str(entry.get('id') or ''),
					item.get('image') or '', str(entry.get('score') if entry.get('score') is not None else ''), entry.get('created_at') or ''))
			_reconcile_rows(cursor, table, rows, (2,))
		connection.commit()
		return True
	except Exception:
		connection.rollback()
		from resources.lib.modules import log_utils
		log_utils.error()
		return False
	finally:
		connection.close()


def store_bookmarks(rows, expected_revision):
	connection = get_connection()
	try:
		cursor = connection.cursor()
		_ensure_bookmarks_table(cursor)
		connection.execute('BEGIN IMMEDIATE')
		if _read_revision(cursor, 'bookmarks') != expected_revision:
			connection.rollback()
			return False
		_reconcile_rows(cursor, 'bookmarks', rows, (3, 4, 5, 6, 7))
		_bump_revision(cursor, 'bookmarks')
		cursor.execute('INSERT OR REPLACE INTO service VALUES (?, ?)', ('last_paused_at', datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.000Z')))
		connection.commit()
		return True
	except Exception:
		connection.rollback()
		from resources.lib.modules import log_utils
		log_utils.error()
		return False
	finally:
		connection.close()


def reset_for_authorization():
	"""Clear previous-account caches and invalidate in-flight snapshots."""
	connection = get_connection()
	try:
		cursor = connection.cursor()
		connection.execute('BEGIN IMMEDIATE')
		for table in ('bookmarks', 'floppy_watched_movies', 'floppy_watched_episodes', 'watched',
			'sync_mirror', 'sync_context',
			'movies_plantowatch', 'shows_plantowatch', 'movies_watching', 'shows_watching',
			'movies_hold', 'shows_hold', 'movies_completed', 'shows_completed',
			'movies_dropped', 'shows_dropped', 'movies_collection', 'shows_collection'):
			if cursor.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone():
				cursor.execute('DELETE FROM ' + table)
		_bump_revision(cursor, 'history')
		_bump_revision(cursor, 'bookmarks')
		cursor.execute('INSERT OR REPLACE INTO service VALUES (?, ?)', ('last_history_at', '1970-01-01T00:00:00.000Z'))
		connection.commit()
		return True
	except Exception:
		connection.rollback()
		from resources.lib.modules import log_utils
		log_utils.error()
		return False
	finally:
		connection.close()


def load_incremental():
	import json
	connection = get_connection()
	try:
		cursor = connection.cursor()
		cursor.execute('CREATE TABLE IF NOT EXISTS sync_context (id INTEGER PRIMARY KEY, payload TEXT)')
		cursor.execute('CREATE TABLE IF NOT EXISTS sync_mirror (resource TEXT, item_id TEXT, payload TEXT, PRIMARY KEY(resource,item_id))')
		row = cursor.execute('SELECT payload FROM sync_context WHERE id=1').fetchone()
		mirror = {'watched': {}, 'progress': {}}
		for resource, item_id, payload in cursor.execute('SELECT * FROM sync_mirror'):
			mirror[resource][item_id] = json.loads(payload)
		connection.commit()
		return json.loads(row[0]) if row else None, mirror
	finally:
		connection.close()


def store_incremental(state, mirror, movies, episodes, bookmarks, revisions):
	"""Publish both caught-up resources and their cursors in one durable transaction."""
	import json
	connection = get_connection()
	try:
		cursor = connection.cursor()
		_ensure_watched_tables(cursor)
		_ensure_bookmarks_table(cursor)
		connection.execute('BEGIN IMMEDIATE')
		if any(_read_revision(cursor, resource) != revision for resource, revision in revisions.items()):
			connection.rollback()
			return False
		# The raw mirror retains hidden/completed progress. A later unwatched
		# assertion can make an existing partial resume visible again.
		rows = [(resource, key, json.dumps(value, sort_keys=True, separators=(',', ':')))
			for resource, items in mirror.items() for key, value in items.items()]
		_reconcile_rows(cursor, 'sync_mirror', rows, (0, 1))
		_reconcile_rows(cursor, 'floppy_watched_movies', movies, (1,))
		_reconcile_rows(cursor, 'floppy_watched_episodes', episodes, (1, 3, 4))
		_reconcile_rows(cursor, 'bookmarks', bookmarks, (3, 4, 5, 6, 7))
		cursor.execute('INSERT OR REPLACE INTO sync_context VALUES (1, ?)', (json.dumps(state),))
		now = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.000Z')
		for resource, timestamp in (('history', 'last_history_at'), ('bookmarks', 'last_paused_at')):
			_bump_revision(cursor, resource)
			cursor.execute('INSERT OR REPLACE INTO service VALUES (?, ?)', (timestamp, now))
		connection.commit()
		return True
	except Exception:
		connection.rollback()
		raise
	finally:
		connection.close()
